# LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct

중간 층 ℳ = 8–22 (전체 30층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9901960784313726,
 "final_layer_max_abs_dlogp": 0.042893826961517334,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=8: R²=0.459 (λ=0.1), ℓ=9: R²=0.476 (λ=0.1), ℓ=10: R²=0.488 (λ=0.1), ℓ=11: R²=0.490 (λ=0.1), ℓ=12: R²=0.493 (λ=0.1), ℓ=13: R²=0.501 (λ=0.1), ℓ=14: R²=0.509 (λ=0.1), ℓ=15: R²=0.516 (λ=0.1), ℓ=16: R²=0.525 (λ=0.1), ℓ=17: R²=0.533 (λ=0.1), ℓ=18: R²=0.538 (λ=0.1), ℓ=19: R²=0.552 (λ=0.1), ℓ=20: R²=0.563 (λ=0.1), ℓ=21: R²=0.576 (λ=0.1), ℓ=22: R²=0.590 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=8: 8.52→2.37, ℓ=9: 8.47→2.30, ℓ=10: 8.47→2.25, ℓ=11: 8.54→2.20, ℓ=12: 8.47→2.19, ℓ=13: 8.52→2.15, ℓ=14: 8.48→2.06, ℓ=15: 8.24→2.02, ℓ=16: 8.20→1.96, ℓ=17: 8.17→1.93, ℓ=18: 7.96→1.89, ℓ=19: 7.59→1.80, ℓ=20: 7.34→1.71, ℓ=21: 7.01→1.63, ℓ=22: 6.58→1.53

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: '\n'×3548, '大'×26, '�'×14, '�'×10, '人'×2
- affine_nobias: '\n'×3450, '�'×76, '大'×48, '�'×24, '人'×2
- logit: ' chuckled'×871, ' respectfully'×339, ' —.'×188, 'onas'×157, 'icho'×131, 'år'×130, ' sweet'×120, 'ucc'×116, ' debatable'×114, ' Philippe'×112, ' standout'×100, ' Medicine'×98
- mean_task: ' gamb'×120, ' 겠다는'×102, ' trailing'×102, ' Jain'×100, 'yth'×89, ' Macron'×62, 'grav'×61, '욕장'×60, 'ho'×60, ' Lay'×60, '�'×60, ' 완'×60
- mean_wiki: ' chuckled'×464, 'icho'×362, ' infiltr'×320, '듬해'×278, 'ivas'×250, ' outnumber'×240, ' Matth'×240, ' %/'×238, ' respectfully'×236, '[|endofturn|]'×130, ' prolifer'×124, 'lon'×108
- tuned: '\n'×763, '[|endofturn|]'×560, ' chuckled'×557, '  '×437, '('×243, 'N'×238, '현'×180, '�'×114, '접'×106, '�'×100, '지상'×76, ' 주인공'×64

## 문항 집합: own_correct (문항 24, 영어 단어 24)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | -0.392 | [-0.706, 0.076] | - | - | -0.427 |
| mean_task | 0.352 | [-0.173, 0.734] | 0.744 | [0.073, 1.200] | 0.535 |
| mean_wiki | -0.376 | [-0.718, 0.176] | 0.016 | [-0.243, 0.303] | -0.401 |
| affine | -0.147 | [-0.601, 0.374] | 0.246 | [-0.411, 0.830] | -0.155 |
| affine_nobias | -0.185 | [-0.626, 0.321] | 0.207 | [-0.424, 0.760] | -0.196 |
| tuned | -0.463 | [-0.809, 0.074] | -0.071 | [-0.506, 0.356] | -0.487 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 4.665, 평균 I_en(영어 입력) = 0.844, I_en > I 비율 = 0.042, Wilcoxon p = 3.6e-07. I > 0 비율 = 0.917
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 16 | 4.295 | -0.317 | 0.283 | -0.103 | -0.179 | -0.170 | -0.442 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.912 | Y |
| s_logit | 0.925 | Y |
| s_mean_task | 0.476 | N |
| s_mean_wiki | 0.965 | Y |
| s_affine | 0.983 | Y |
| s_affine_nobias | 0.979 | Y |
| s_tuned | 0.992 | Y |

템플릿별 lens 순위: T1: mean_task > affine > affine_nobias > logit > mean_wiki > tuned; T2: mean_task > affine_nobias > affine > logit > tuned > mean_wiki; T3: mean_task > affine > affine_nobias > logit > mean_wiki > tuned; T4: mean_task > affine > affine_nobias > mean_wiki > logit > tuned

불일치 (logit lens 높음·간섭 낮음): B051(wish), B015(apology), B047(glue), B063(doubt), B045(household), B083(region), B055(capacity), B039(intention)

불일치 (logit lens 낮음·간섭 높음): B041(biography), B111(extinguishing), B004(eye), B003(snow), B105(guidance), B069(cremation), B011(tea), B053(distance)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.354 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.097 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.200, affine_nobias=0.118, logit=0.667, mean_task=0.704, mean_wiki=0.673, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.200 | 0.104 | 0.062 | 15.668 | 16.463 |
| affine_nobias | 0.118 | 0.087 | 0.137 | 13.120 | 13.605 |
| logit | 0.667 | 0.667 | 0.944 | 10.952 | 11.177 |
| mean_task | 0.704 | 0.703 | 0.950 | 10.978 | 11.093 |
| mean_wiki | 0.673 | 0.673 | 0.944 | 11.134 | 11.188 |
| tuned | 0.553 | 0.552 | 0.905 | 9.091 | 9.218 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -17.59 | -17.85 | 0.26 [-0.69, 1.19] | -0.03 [-0.05, -0.00] | -6.62 [-7.39, -5.88] | -0.05 [-0.08, -0.01] |
| affine_nobias | -14.73 | -15.26 | 0.53 [-0.24, 1.33] | -0.03 [-0.05, -0.00] | -3.77 [-4.43, -3.15] | -0.04 [-0.07, -0.01] |
| logit | -10.96 | -13.08 | 2.12 [1.73, 2.51] | 0.02 [0.00, 0.03] | - | - |
| mean_task | -11.14 | -13.03 | 1.89 [1.70, 2.06] | 0.05 [-0.00, 0.11] | -0.18 [-0.50, 0.14] | 0.04 [-0.01, 0.08] |
| mean_wiki | -11.15 | -13.26 | 2.11 [1.64, 2.60] | 0.02 [0.00, 0.03] | -0.18 [-0.35, -0.01] | 0.00 [-0.00, 0.01] |
| tuned | -10.45 | -11.20 | 0.75 [0.21, 1.29] | 0.02 [-0.00, 0.04] | 0.51 [0.12, 0.88] | 0.00 [-0.02, 0.02] |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.503, remainder=0.200
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.472, remainder=0.200
- order_affine_then_mu: affine_share=0.549, mu_share=-0.082, remainder=0.200

**repeat** E: affine=0.203, affine_nobias=0.119, logit=0.671, mean_task=0.729, mean_wiki=0.679, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.203 | 0.092 | 0.002 | 16.953 | 16.758 |
| affine_nobias | 0.119 | 0.033 | 0.046 | 13.522 | 13.518 |
| logit | 0.671 | 0.671 | 0.946 | 12.880 | 12.895 |
| mean_task | 0.729 | 0.729 | 0.962 | 14.273 | 14.175 |
| mean_wiki | 0.679 | 0.679 | 0.947 | 12.378 | 12.414 |
| tuned | 0.553 | 0.552 | 0.931 | 11.372 | 11.397 |

- order_mu_then_affine[mean_task]: mu_share=-0.059, affine_share=0.526, remainder=0.203
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.475, remainder=0.203
- order_affine_then_mu: affine_share=0.552, mu_share=-0.085, remainder=0.203

## 문항 집합: common_correct (문항 22, 영어 단어 22)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | -0.410 | [-0.755, 0.047] | - | - | -0.446 |
| mean_task | 0.276 | [-0.210, 0.708] | 0.686 | [0.089, 1.227] | 0.451 |
| mean_wiki | -0.337 | [-0.723, 0.176] | 0.073 | [-0.157, 0.336] | -0.362 |
| affine | -0.177 | [-0.625, 0.342] | 0.233 | [-0.416, 0.813] | -0.189 |
| affine_nobias | -0.220 | [-0.654, 0.307] | 0.190 | [-0.436, 0.769] | -0.235 |
| tuned | -0.470 | [-0.849, 0.078] | -0.060 | [-0.482, 0.387] | -0.499 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 4.379, 평균 I_en(영어 입력) = 0.774, I_en > I 비율 = 0.045, Wilcoxon p = 1.4e-06. I > 0 비율 = 0.909
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 15 | 4.274 | -0.325 | 0.302 | -0.122 | -0.176 | -0.182 | -0.413 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.898 | Y |
| s_logit | 0.940 | Y |
| s_mean_task | 0.417 | N |
| s_mean_wiki | 0.965 | Y |
| s_affine | 0.981 | Y |
| s_affine_nobias | 0.974 | Y |
| s_tuned | 0.990 | Y |

템플릿별 lens 순위: T1: mean_task > affine > affine_nobias > logit > mean_wiki > tuned; T2: mean_task > affine_nobias > affine > tuned > mean_wiki > logit; T3: mean_task > affine > affine_nobias > logit > mean_wiki > tuned; T4: mean_task > affine > affine_nobias > mean_wiki > logit > tuned

불일치 (logit lens 높음·간섭 낮음): B051(wish), B015(apology), B047(glue), B063(doubt), B045(household), B055(capacity), B083(region), B039(intention)

불일치 (logit lens 낮음·간섭 높음): B041(biography), B111(extinguishing), B004(eye), B105(guidance), B069(cremation), B011(tea), B053(distance), B001(pear)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.362 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.154 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.200, affine_nobias=0.118, logit=0.667, mean_task=0.703, mean_wiki=0.673, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.200 | 0.105 | 0.062 | 15.833 | 16.632 |
| affine_nobias | 0.118 | 0.087 | 0.137 | 13.272 | 13.759 |
| logit | 0.667 | 0.667 | 0.944 | 11.019 | 11.198 |
| mean_task | 0.703 | 0.703 | 0.950 | 11.049 | 11.115 |
| mean_wiki | 0.673 | 0.673 | 0.944 | 11.195 | 11.221 |
| tuned | 0.553 | 0.552 | 0.905 | 9.194 | 9.286 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -17.65 | -17.91 | 0.26 [-0.74, 1.33] | -0.03 [-0.05, 0.00] | -6.73 [-7.55, -5.94] | -0.04 [-0.07, -0.01] |
| affine_nobias | -14.75 | -15.30 | 0.55 [-0.32, 1.39] | -0.02 [-0.05, 0.00] | -3.83 [-4.52, -3.08] | -0.04 [-0.07, -0.00] |
| logit | -10.92 | -12.99 | 2.07 [1.66, 2.49] | 0.01 [0.00, 0.03] | - | - |
| mean_task | -11.19 | -13.02 | 1.83 [1.66, 2.00] | 0.04 [-0.02, 0.09] | -0.27 [-0.61, 0.05] | 0.03 [-0.02, 0.07] |
| mean_wiki | -11.10 | -13.16 | 2.05 [1.55, 2.57] | 0.02 [-0.00, 0.03] | -0.18 [-0.35, -0.01] | 0.00 [-0.00, 0.01] |
| tuned | -10.41 | -11.18 | 0.77 [0.15, 1.41] | 0.02 [-0.00, 0.04] | 0.51 [0.10, 0.94] | 0.00 [-0.02, 0.02] |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.503, remainder=0.200
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.472, remainder=0.200
- order_affine_then_mu: affine_share=0.549, mu_share=-0.082, remainder=0.200

**repeat** E: affine=0.202, affine_nobias=0.118, logit=0.671, mean_task=0.729, mean_wiki=0.679, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.202 | 0.092 | 0.002 | 16.976 | 16.783 |
| affine_nobias | 0.118 | 0.033 | 0.047 | 13.543 | 13.547 |
| logit | 0.671 | 0.671 | 0.946 | 12.894 | 12.903 |
| mean_task | 0.729 | 0.729 | 0.962 | 14.280 | 14.186 |
| mean_wiki | 0.679 | 0.679 | 0.947 | 12.395 | 12.434 |
| tuned | 0.553 | 0.552 | 0.930 | 11.385 | 11.402 |

- order_mu_then_affine[mean_task]: mu_share=-0.059, affine_share=0.527, remainder=0.202
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.477, remainder=0.202
- order_affine_then_mu: affine_share=0.553, mu_share=-0.084, remainder=0.202
