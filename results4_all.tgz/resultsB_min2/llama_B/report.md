# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9950980392156863,
 "final_layer_max_abs_dlogp": 0.04313063621520996,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.500 (λ=1), ℓ=8: R²=0.502 (λ=1), ℓ=9: R²=0.508 (λ=1), ℓ=10: R²=0.516 (λ=1), ℓ=11: R²=0.521 (λ=1), ℓ=12: R²=0.533 (λ=1), ℓ=13: R²=0.546 (λ=0.1), ℓ=14: R²=0.568 (λ=0.1), ℓ=15: R²=0.584 (λ=0.1), ℓ=16: R²=0.604 (λ=0.1), ℓ=17: R²=0.616 (λ=0.1), ℓ=18: R²=0.623 (λ=0.1), ℓ=19: R²=0.632 (λ=0.1), ℓ=20: R²=0.647 (λ=0.1), ℓ=21: R²=0.662 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=7: 8.99→2.46, ℓ=8: 8.86→2.43, ℓ=9: 8.92→2.38, ℓ=10: 8.88→2.33, ℓ=11: 8.76→2.30, ℓ=12: 8.58→2.21, ℓ=13: 8.32→2.09, ℓ=14: 8.07→1.97, ℓ=15: 7.66→1.80, ℓ=16: 7.00→1.64, ℓ=17: 6.61→1.52, ℓ=18: 6.35→1.45, ℓ=19: 6.06→1.36, ℓ=20: 5.71→1.24, ℓ=21: 5.39→1.14

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: ' '×1996, '1'×142, '\xa0'×124, ' 사'×100, '大'×94, ' ('×68, '人'×60, '的'×44, '小'×44, '一'×38, ' 유'×36, ' 기'×36
- affine_nobias: ' '×1934, '1'×192, '大'×112, ' 사'×96, '人'×74, ' ('×62, '\xa0'×60, '的'×56, '小'×46, '一'×34, '女'×34, ' 유'×33
- logit: 'afi'×205, ' ders'×110, 'anzi'×108, 'uada'×96, 'wis'×86, 'onium'×72, ' Platt'×56, ' electricity'×56, 'stro'×50, ' Gef'×48, 'iger'×46, ' furniture'×44
- mean_task: 'upo'×79, ' wind'×60, ' sleep'×58, ' electricity'×56, ' meetings'×52, ' accident'×48, ' grass'×44, ' night'×44, ' furniture'×44, ' digestion'×44, ' household'×40, ' wife'×40
- mean_wiki: 'afi'×135, 'onium'×132, 'ady'×96, 'allon'×88, 'iger'×67, 'IFS'×56, ' electricity'×54, ' wind'×54, ' sleep'×52, 'quiv'×50, ' Platt'×44, 'ruba'×43
- tuned: ' '×295, '散'×218, '人'×158, '�'×109, '동'×100, '什'×92, '�'×81, '�'×70, '医'×56, ' 공'×52, '电'×52, ' "'×48

## 문항 집합: own_correct (문항 26, 영어 단어 26)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.299 | [-0.141, 0.648] | - | - | 0.338 |
| mean_task | 0.326 | [-0.143, 0.712] | 0.027 | [-0.227, 0.313] | 0.400 |
| mean_wiki | 0.303 | [-0.141, 0.650] | 0.004 | [-0.120, 0.117] | 0.349 |
| affine | 0.158 | [-0.283, 0.506] | -0.141 | [-0.528, 0.233] | 0.189 |
| affine_nobias | 0.128 | [-0.306, 0.506] | -0.171 | [-0.589, 0.235] | 0.152 |
| tuned | 0.092 | [-0.386, 0.515] | -0.207 | [-0.548, 0.091] | 0.125 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 4.012, 평균 I_en(영어 입력) = 0.409, I_en > I 비율 = 0.077, Wilcoxon p = 1.6e-06. I > 0 비율 = 0.962
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 17 | 3.640 | 0.107 | 0.040 | 0.119 | -0.012 | 0.033 | -0.032 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.847 | Y |
| s_logit | 0.926 | Y |
| s_mean_task | 0.785 | Y |
| s_mean_wiki | 0.893 | Y |
| s_affine | 0.826 | Y |
| s_affine_nobias | 0.837 | Y |
| s_tuned | 0.647 | N |

템플릿별 lens 순위: T1: affine > affine_nobias > logit > mean_wiki > mean_task > tuned; T2: mean_task > logit > mean_wiki > affine_nobias > affine > tuned; T3: logit > mean_task > mean_wiki > affine > affine_nobias > tuned; T4: mean_wiki > logit > mean_task > affine_nobias > affine > tuned

불일치 (logit lens 높음·간섭 낮음): B045(household), B066(bride), B055(capacity), B011(tea), B015(apology), B053(distance), B069(cremation), B063(doubt)

불일치 (logit lens 낮음·간섭 높음): B059(thinking), B117(denial), B111(extinguishing), B119(surface), B083(region), B093(audit), B025(morale), B004(eye)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.145 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.323 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.437, affine_nobias=0.353, logit=0.942, mean_task=0.955, mean_wiki=0.948, tuned=0.381

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.437 | 0.158 | 0.478 | 8.514 | 6.617 |
| affine_nobias | 0.353 | 0.178 | 0.527 | 7.405 | 6.436 |
| logit | 0.942 | 0.943 | 0.879 | 8.911 | 8.904 |
| mean_task | 0.955 | 0.956 | 0.913 | 11.038 | 10.468 |
| mean_wiki | 0.948 | 0.949 | 0.874 | 9.252 | 9.233 |
| tuned | 0.381 | 0.368 | 0.918 | 6.603 | 6.566 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -13.01 | -10.20 | -2.81 [-3.63, -1.98] | 0.73 [0.37, 1.09] | -2.20 [-2.94, -1.36] | -0.36 [-0.58, -0.12] |
| affine_nobias | -12.21 | -9.07 | -3.14 [-3.87, -2.34] | 0.71 [0.38, 1.06] | -1.40 [-2.10, -0.69] | -0.39 [-0.63, -0.16] |
| logit | -10.81 | -10.50 | -0.31 [-0.99, 0.36] | 1.09 [0.61, 1.54] | - | - |
| mean_task | -13.21 | -12.48 | -0.73 [-1.95, 0.42] | 1.66 [0.79, 2.55] | -2.40 [-3.09, -1.67] | 0.56 [0.05, 1.05] |
| mean_wiki | -11.33 | -10.81 | -0.52 [-1.25, 0.26] | 1.20 [0.71, 1.72] | -0.51 [-0.65, -0.37] | 0.11 [0.01, 0.20] |
| tuned | -10.81 | -8.27 | -2.54 [-3.16, -1.88] | 0.88 [0.48, 1.30] | 0.00 [-0.33, 0.35] | -0.21 [-0.42, -0.02] |

- order_mu_then_affine[mean_task]: mu_share=-0.012, affine_share=0.518, remainder=0.437
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.511, remainder=0.437
- order_affine_then_mu: affine_share=0.589, mu_share=-0.083, remainder=0.437

**repeat** E: affine=0.392, affine_nobias=0.270, logit=0.929, mean_task=0.927, mean_wiki=0.936, tuned=0.409

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.392 | 0.039 | 0.550 | 7.883 | 5.778 |
| affine_nobias | 0.270 | 0.070 | 0.634 | 6.538 | 5.335 |
| logit | 0.929 | 0.929 | 0.856 | 10.275 | 10.708 |
| mean_task | 0.927 | 0.928 | 0.868 | 10.582 | 11.200 |
| mean_wiki | 0.936 | 0.936 | 0.850 | 10.301 | 10.733 |
| tuned | 0.409 | 0.399 | 0.902 | 5.450 | 6.027 |

- order_mu_then_affine[mean_task]: mu_share=0.002, affine_share=0.535, remainder=0.392
- order_mu_then_affine[mean_wiki]: mu_share=-0.007, affine_share=0.544, remainder=0.392
- order_affine_then_mu: affine_share=0.659, mu_share=-0.122, remainder=0.392

## 문항 집합: common_correct (문항 22, 영어 단어 22)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.333 | [-0.092, 0.692] | - | - | 0.372 |
| mean_task | 0.339 | [-0.133, 0.747] | 0.007 | [-0.278, 0.339] | 0.423 |
| mean_wiki | 0.341 | [-0.087, 0.697] | 0.008 | [-0.130, 0.148] | 0.392 |
| affine | 0.152 | [-0.345, 0.573] | -0.180 | [-0.651, 0.236] | 0.182 |
| affine_nobias | 0.090 | [-0.371, 0.535] | -0.243 | [-0.718, 0.206] | 0.106 |
| tuned | 0.002 | [-0.473, 0.483] | -0.331 | [-0.705, 0.004] | 0.002 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 3.763, 평균 I_en(영어 입력) = 0.467, I_en > I 비율 = 0.091, Wilcoxon p = 2.6e-05. I > 0 비율 = 0.955
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 15 | 3.618 | 0.174 | 0.066 | 0.175 | 0.033 | 0.033 | 0.004 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.848 | Y |
| s_logit | 0.945 | Y |
| s_mean_task | 0.759 | Y |
| s_mean_wiki | 0.894 | Y |
| s_affine | 0.828 | Y |
| s_affine_nobias | 0.849 | Y |
| s_tuned | 0.683 | N |

템플릿별 lens 순위: T1: logit > affine > mean_wiki > mean_task > affine_nobias > tuned; T2: mean_task > logit > mean_wiki > affine > affine_nobias > tuned; T3: logit > mean_task > mean_wiki > affine_nobias > affine > tuned; T4: mean_wiki > logit > affine > mean_task > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): B045(household), B055(capacity), B011(tea), B015(apology), B069(cremation), B053(distance), B105(guidance), B063(doubt)

불일치 (logit lens 낮음·간섭 높음): B059(thinking), B117(denial), B111(extinguishing), B119(surface), B083(region), B093(audit), B004(eye), B014(bottle)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.213 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.414 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.436, affine_nobias=0.352, logit=0.942, mean_task=0.954, mean_wiki=0.948, tuned=0.386

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.436 | 0.157 | 0.473 | 8.718 | 6.763 |
| affine_nobias | 0.352 | 0.177 | 0.522 | 7.589 | 6.633 |
| logit | 0.942 | 0.943 | 0.880 | 9.072 | 9.238 |
| mean_task | 0.954 | 0.956 | 0.913 | 11.203 | 10.640 |
| mean_wiki | 0.948 | 0.949 | 0.875 | 9.390 | 9.574 |
| tuned | 0.386 | 0.373 | 0.918 | 6.757 | 6.843 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -13.30 | -10.10 | -3.20 [-3.97, -2.32] | 0.58 [0.23, 0.92] | -2.34 [-3.22, -1.47] | -0.40 [-0.66, -0.13] |
| affine_nobias | -12.47 | -8.95 | -3.53 [-4.27, -2.76] | 0.56 [0.24, 0.92] | -1.51 [-2.27, -0.67] | -0.42 [-0.68, -0.13] |
| logit | -10.96 | -10.40 | -0.56 [-1.15, 0.13] | 0.98 [0.50, 1.46] | - | - |
| mean_task | -13.56 | -12.36 | -1.20 [-2.53, -0.00] | 1.44 [0.50, 2.43] | -2.61 [-3.41, -1.79] | 0.47 [-0.04, 0.98] |
| mean_wiki | -11.50 | -10.67 | -0.82 [-1.64, -0.02] | 1.05 [0.53, 1.55] | -0.54 [-0.69, -0.38] | 0.08 [-0.02, 0.18] |
| tuned | -10.97 | -8.12 | -2.85 [-3.45, -2.24] | 0.76 [0.39, 1.20] | -0.01 [-0.37, 0.36] | -0.21 [-0.45, 0.02] |

- order_mu_then_affine[mean_task]: mu_share=-0.012, affine_share=0.518, remainder=0.436
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.512, remainder=0.436
- order_affine_then_mu: affine_share=0.591, mu_share=-0.084, remainder=0.436

**repeat** E: affine=0.391, affine_nobias=0.269, logit=0.929, mean_task=0.927, mean_wiki=0.936, tuned=0.413

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.391 | 0.039 | 0.551 | 7.960 | 5.836 |
| affine_nobias | 0.269 | 0.069 | 0.636 | 6.606 | 5.414 |
| logit | 0.929 | 0.930 | 0.858 | 10.261 | 10.742 |
| mean_task | 0.927 | 0.928 | 0.869 | 10.501 | 11.106 |
| mean_wiki | 0.936 | 0.937 | 0.852 | 10.294 | 10.734 |
| tuned | 0.413 | 0.403 | 0.901 | 5.513 | 6.058 |

- order_mu_then_affine[mean_task]: mu_share=0.002, affine_share=0.536, remainder=0.391
- order_mu_then_affine[mean_wiki]: mu_share=-0.007, affine_share=0.545, remainder=0.391
- order_affine_then_mu: affine_share=0.661, mu_share=-0.122, remainder=0.391
