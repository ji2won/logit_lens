# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9884778653729533,
 "final_layer_max_abs_dlogp": 0.054591476917266846,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.500 (λ=1), ℓ=8: R²=0.502 (λ=1), ℓ=9: R²=0.508 (λ=1), ℓ=10: R²=0.516 (λ=1), ℓ=11: R²=0.521 (λ=1), ℓ=12: R²=0.533 (λ=1), ℓ=13: R²=0.546 (λ=0.1), ℓ=14: R²=0.568 (λ=0.1), ℓ=15: R²=0.584 (λ=0.1), ℓ=16: R²=0.604 (λ=0.1), ℓ=17: R²=0.616 (λ=0.1), ℓ=18: R²=0.623 (λ=0.1), ℓ=19: R²=0.632 (λ=0.1), ℓ=20: R²=0.647 (λ=0.1), ℓ=21: R²=0.662 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=7: 8.99→2.46, ℓ=8: 8.86→2.43, ℓ=9: 8.92→2.38, ℓ=10: 8.88→2.33, ℓ=11: 8.76→2.30, ℓ=12: 8.58→2.21, ℓ=13: 8.32→2.09, ℓ=14: 8.07→1.97, ℓ=15: 7.66→1.80, ℓ=16: 7.00→1.64, ℓ=17: 6.61→1.52, ℓ=18: 6.35→1.45, ℓ=19: 6.06→1.36, ℓ=20: 5.71→1.24, ℓ=21: 5.39→1.14

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: ' '×2902, '1'×268, '大'×202, '\xa0'×141, '小'×107, ' 사'×102, ' 기'×95, ' �'×81, '的'×68, ' 유'×67, ' �'×65, '一'×61
- affine_nobias: ' '×2786, '1'×328, '大'×237, '小'×123, '\xa0'×110, '的'×93, ' 사'×93, ' 기'×93, ' �'×79, 'A'×70, ' �'×61, ' 유'×55
- logit: 'afi'×267, 'anzi'×180, 'uada'×154, 'onium'×145, 'wis'×144, ' ders'×121, 'arious'×113, 'pert'×102, 'omat'×94, 'stro'×87, 'vir'×82, 'ーズ'×75
- mean_task: 'upo'×113, ' golf'×49, 'jian'×48, 'olina'×44, 'wards'×42, ' eyes'×38, ' plants'×35, ' fingers'×30, ' storyline'×29, ' \u200b\u200b'×28, ' magazine'×28, ' waves'×28
- mean_wiki: 'onium'×258, 'afi'×190, 'ady'×133, 'quiv'×98, 'ruba'×83, 'allon'×67, 'arious'×60, 'lei'×58, 'IFS'×58, 'ož'×57, ' Platt'×52, 'ellig'×50
- tuned: ' '×498, '�'×265, '人'×228, '�'×200, '散'×199, '排'×144, '�'×143, '동'×119, '�'×111, ' "'×94, '什'×81, 'K'×79

## 문항 집합: own_correct (문항 48, 영어 단어 45)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.248 | [-0.078, 0.517] | - | - | 0.262 |
| mean_task | 0.223 | [-0.099, 0.489] | -0.025 | [-0.175, 0.143] | 0.237 |
| mean_wiki | 0.221 | [-0.116, 0.497] | -0.027 | [-0.100, 0.043] | 0.233 |
| affine | 0.126 | [-0.179, 0.380] | -0.122 | [-0.358, 0.097] | 0.136 |
| affine_nobias | 0.135 | [-0.166, 0.401] | -0.114 | [-0.338, 0.102] | 0.147 |
| tuned | 0.230 | [-0.070, 0.460] | -0.018 | [-0.193, 0.146] | 0.243 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 1.037, 평균 I_en(영어 입력) = 6.257, I_en > I 비율 = 0.938, Wilcoxon p = 9.9e-14. I > 0 비율 = 0.667
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 고유어 | 18 | 1.036 | 0.244 | -0.000 | 0.170 | 0.026 | -0.086 | 0.205 |
| 한자어 | 16 | 0.790 | 0.354 | 0.315 | 0.421 | 0.227 | 0.248 | 0.257 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.910 | Y |
| s_logit | 0.989 | Y |
| s_mean_task | 0.981 | Y |
| s_mean_wiki | 0.989 | Y |
| s_affine | 0.946 | Y |
| s_affine_nobias | 0.919 | Y |
| s_tuned | 0.986 | Y |

템플릿별 lens 순위: T1: logit > tuned > mean_wiki > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T3: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T4: tuned > mean_wiki > logit > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A006(palm), A057(glasses), A131(tie), A157(lid), A159(spine), A096(vessel)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A122(mold), A056(game), A084(interest), A052(digit), A078(bar), A026(star), A002(fall)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.130 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.006 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.435, affine_nobias=0.353, logit=0.940, mean_task=0.954, mean_wiki=0.946, tuned=0.383

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.435 | 0.165 | 0.512 | 8.988 | 7.175 |
| affine_nobias | 0.353 | 0.184 | 0.565 | 7.890 | 6.982 |
| logit | 0.940 | 0.940 | 0.876 | 9.302 | 9.341 |
| mean_task | 0.954 | 0.956 | 0.912 | 10.968 | 10.615 |
| mean_wiki | 0.946 | 0.947 | 0.870 | 9.585 | 9.573 |
| tuned | 0.383 | 0.369 | 0.917 | 7.005 | 7.091 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -11.47 | -10.34 | -1.13 [-1.75, -0.52] | 1.04 [0.81, 1.27] | -3.26 [-3.70, -2.79] | -1.26 [-1.50, -1.03] |
| affine_nobias | -10.74 | -9.23 | -1.51 [-2.07, -0.94] | 1.00 [0.79, 1.21] | -2.53 [-2.98, -2.12] | -1.30 [-1.53, -1.06] |
| logit | -8.21 | -10.56 | 2.35 [1.86, 2.77] | 2.30 [2.00, 2.64] | - | - |
| mean_task | -7.80 | -12.06 | 4.26 [3.60, 4.90] | 4.02 [3.40, 4.64] | 0.41 [0.08, 0.71] | 1.72 [1.41, 2.02] |
| mean_wiki | -8.30 | -10.83 | 2.53 [2.05, 3.03] | 2.60 [2.24, 2.99] | -0.09 [-0.21, 0.03] | 0.30 [0.24, 0.36] |
| tuned | -8.51 | -8.32 | -0.19 [-0.66, 0.28] | 1.80 [1.51, 2.06] | -0.30 [-0.48, -0.12] | -0.51 [-0.68, -0.34] |

- order_mu_then_affine[mean_task]: mu_share=-0.014, affine_share=0.518, remainder=0.435
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.510, remainder=0.435
- order_affine_then_mu: affine_share=0.587, mu_share=-0.082, remainder=0.435

**repeat** E: affine=0.394, affine_nobias=0.270, logit=0.927, mean_task=0.928, mean_wiki=0.933, tuned=0.413

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.394 | 0.039 | 0.553 | 8.230 | 6.227 |
| affine_nobias | 0.270 | 0.068 | 0.636 | 6.862 | 5.726 |
| logit | 0.927 | 0.928 | 0.853 | 10.661 | 11.001 |
| mean_task | 0.928 | 0.928 | 0.866 | 10.960 | 11.429 |
| mean_wiki | 0.933 | 0.933 | 0.845 | 10.791 | 11.218 |
| tuned | 0.413 | 0.403 | 0.899 | 5.979 | 6.338 |

- order_mu_then_affine[mean_task]: mu_share=-0.000, affine_share=0.534, remainder=0.394
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.539, remainder=0.394
- order_affine_then_mu: affine_share=0.657, mu_share=-0.124, remainder=0.394

## 문항 집합: common_correct (문항 32, 영어 단어 30)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.319 | [-0.076, 0.623] | - | - | 0.339 |
| mean_task | 0.252 | [-0.136, 0.559] | -0.067 | [-0.302, 0.158] | 0.268 |
| mean_wiki | 0.292 | [-0.100, 0.602] | -0.027 | [-0.144, 0.083] | 0.310 |
| affine | 0.158 | [-0.236, 0.516] | -0.161 | [-0.444, 0.124] | 0.170 |
| affine_nobias | 0.195 | [-0.190, 0.551] | -0.124 | [-0.401, 0.164] | 0.213 |
| tuned | 0.285 | [-0.070, 0.589] | -0.034 | [-0.264, 0.210] | 0.303 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 1.036, 평균 I_en(영어 입력) = 5.818, I_en > I 비율 = 0.906, Wilcoxon p = 6.5e-09. I > 0 비율 = 0.656
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 고유어 | 10 | 1.014 | 0.264 | -0.041 | 0.264 | -0.298 | -0.270 | -0.084 |
| 한자어 | 12 | 0.852 | 0.348 | 0.302 | 0.402 | 0.099 | 0.110 | 0.095 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.896 | Y |
| s_logit | 0.988 | Y |
| s_mean_task | 0.986 | Y |
| s_mean_wiki | 0.990 | Y |
| s_affine | 0.958 | Y |
| s_affine_nobias | 0.928 | Y |
| s_tuned | 0.987 | Y |

템플릿별 lens 순위: T1: logit > tuned > mean_wiki > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T3: mean_wiki > logit > tuned > mean_task > affine_nobias > affine; T4: logit > tuned > mean_wiki > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A057(glasses), A157(lid), A190(duck), A096(vessel), A099(ear), A014(key)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A026(star), A002(fall), A034(cell), A203(pupil), A095(term), A206(letter), A081(diamond)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.035 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.304 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.438, affine_nobias=0.352, logit=0.939, mean_task=0.955, mean_wiki=0.946, tuned=0.386

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.438 | 0.169 | 0.507 | 9.053 | 7.283 |
| affine_nobias | 0.352 | 0.188 | 0.560 | 7.927 | 7.080 |
| logit | 0.939 | 0.940 | 0.875 | 9.303 | 9.348 |
| mean_task | 0.955 | 0.957 | 0.913 | 11.015 | 10.736 |
| mean_wiki | 0.946 | 0.947 | 0.870 | 9.575 | 9.574 |
| tuned | 0.386 | 0.372 | 0.916 | 7.092 | 7.210 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -11.23 | -10.30 | -0.93 [-1.68, -0.20] | 1.13 [0.87, 1.40] | -3.33 [-3.82, -2.75] | -1.34 [-1.61, -1.08] |
| affine_nobias | -10.50 | -9.16 | -1.34 [-2.06, -0.64] | 1.09 [0.82, 1.38] | -2.60 [-3.05, -2.08] | -1.38 [-1.66, -1.12] |
| logit | -7.90 | -10.40 | 2.50 [2.03, 3.05] | 2.47 [2.09, 2.81] | - | - |
| mean_task | -7.39 | -11.96 | 4.57 [3.83, 5.30] | 4.44 [3.75, 5.10] | 0.51 [0.10, 0.89] | 1.97 [1.63, 2.31] |
| mean_wiki | -7.92 | -10.64 | 2.72 [2.15, 3.30] | 2.80 [2.37, 3.20] | -0.02 [-0.16, 0.13] | 0.33 [0.27, 0.40] |
| tuned | -8.16 | -8.26 | 0.11 [-0.44, 0.62] | 1.88 [1.54, 2.21] | -0.26 [-0.46, -0.07] | -0.59 [-0.79, -0.39] |

- order_mu_then_affine[mean_task]: mu_share=-0.016, affine_share=0.518, remainder=0.438
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.508, remainder=0.438
- order_affine_then_mu: affine_share=0.587, mu_share=-0.086, remainder=0.438

**repeat** E: affine=0.393, affine_nobias=0.268, logit=0.927, mean_task=0.928, mean_wiki=0.933, tuned=0.417

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.393 | 0.039 | 0.554 | 8.240 | 6.127 |
| affine_nobias | 0.268 | 0.069 | 0.639 | 6.860 | 5.515 |
| logit | 0.927 | 0.928 | 0.853 | 10.779 | 11.009 |
| mean_task | 0.928 | 0.929 | 0.866 | 11.066 | 11.448 |
| mean_wiki | 0.933 | 0.933 | 0.845 | 10.937 | 11.327 |
| tuned | 0.417 | 0.407 | 0.899 | 6.081 | 6.417 |

- order_mu_then_affine[mean_task]: mu_share=-0.001, affine_share=0.535, remainder=0.393
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.539, remainder=0.393
- order_affine_then_mu: affine_share=0.660, mu_share=-0.126, remainder=0.393
