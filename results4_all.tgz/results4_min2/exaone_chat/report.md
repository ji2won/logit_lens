# LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct

중간 층 ℳ = 8–22 (전체 30층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9902971497877502,
 "final_layer_max_abs_dlogp": 0.05726444721221924,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=8: R²=0.459 (λ=0.1), ℓ=9: R²=0.476 (λ=0.1), ℓ=10: R²=0.488 (λ=0.1), ℓ=11: R²=0.490 (λ=0.1), ℓ=12: R²=0.493 (λ=0.1), ℓ=13: R²=0.501 (λ=0.1), ℓ=14: R²=0.509 (λ=0.1), ℓ=15: R²=0.516 (λ=0.1), ℓ=16: R²=0.525 (λ=0.1), ℓ=17: R²=0.533 (λ=0.1), ℓ=18: R²=0.538 (λ=0.1), ℓ=19: R²=0.552 (λ=0.1), ℓ=20: R²=0.563 (λ=0.1), ℓ=21: R²=0.576 (λ=0.1), ℓ=22: R²=0.590 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=8: 8.52→2.37, ℓ=9: 8.47→2.30, ℓ=10: 8.47→2.25, ℓ=11: 8.54→2.20, ℓ=12: 8.47→2.19, ℓ=13: 8.52→2.15, ℓ=14: 8.48→2.06, ℓ=15: 8.24→2.02, ℓ=16: 8.20→1.96, ℓ=17: 8.17→1.93, ℓ=18: 7.96→1.89, ℓ=19: 7.59→1.80, ℓ=20: 7.34→1.71, ℓ=21: 7.01→1.63, ℓ=22: 6.58→1.53

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: '\n'×5696, '�'×67, '�'×30, '大'×24, '人'×3
- affine_nobias: '\n'×5515, '�'×172, '�'×66, '大'×61, '人'×6
- logit: ' chuckled'×1380, ' respectfully'×655, ' —.'×318, 'onas'×253, 'icho'×228, ' sweet'×194, 'ucc'×192, ' debatable'×187, ' Philippe'×167, ' %/'×163, ' standout'×158, 'år'×147
- mean_task: ' gamb'×187, ' Jain'×153, 'yth'×147, ' 겠다는'×142, 'grav'×119, ' trailing'×115, ' Lay'×98, '�'×97, ' 완'×97, '욕장'×94, 'loyd'×90, 'idis'×89
- mean_wiki: ' chuckled'×683, 'icho'×627, ' infiltr'×517, '듬해'×427, ' respectfully'×421, 'ivas'×412, ' %/'×404, ' outnumber'×388, ' Matth'×387, ' prolifer'×194, '[|endofturn|]'×191, 'lon'×173
- tuned: '\n'×1293, '[|endofturn|]'×871, ' chuckled'×852, '  '×669, '('×389, 'N'×382, '현'×291, '접'×222, '�'×187, '�'×181, '지상'×108, ' compositional'×94

## 문항 집합: own_correct (문항 43, 영어 단어 41)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.111 | [-0.245, 0.430] | - | - | 0.115 |
| mean_task | 0.222 | [-0.139, 0.479] | 0.110 | [-0.336, 0.503] | 0.807 |
| mean_wiki | 0.116 | [-0.226, 0.449] | 0.004 | [-0.125, 0.157] | 0.120 |
| affine | -0.089 | [-0.384, 0.268] | -0.201 | [-0.639, 0.298] | -0.091 |
| affine_nobias | -0.111 | [-0.415, 0.240] | -0.222 | [-0.639, 0.261] | -0.113 |
| tuned | -0.128 | [-0.377, 0.165] | -0.240 | [-0.538, 0.134] | -0.131 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.702, 평균 I_en(영어 입력) = 4.585, I_en > I 비율 = 0.907, Wilcoxon p = 2.3e-09. I > 0 비율 = 0.581
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 고유어 | 13 | -0.191 | 0.129 | 0.198 | 0.266 | 0.112 | -0.156 | -0.260 |
| 한자어 | 18 | 0.799 | -0.026 | 0.208 | -0.094 | -0.041 | -0.009 | -0.055 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.969 | Y |
| s_logit | 0.971 | Y |
| s_mean_task | 0.078 | N |
| s_mean_wiki | 0.965 | Y |
| s_affine | 0.991 | Y |
| s_affine_nobias | 0.992 | Y |
| s_tuned | 0.983 | Y |

템플릿별 lens 순위: T1: mean_task > logit > mean_wiki > tuned > affine_nobias > affine; T2: mean_task > mean_wiki > logit > affine > affine_nobias > tuned; T3: mean_task > logit > mean_wiki > affine_nobias > affine > tuned; T4: mean_task > logit > mean_wiki > affine > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): A092(staff), A051(deck), A099(ear), A163(corn), A116(plane), A190(duck), A184(bowl), A181(drone)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A034(cell), A095(term), A038(pit), A081(diamond), A036(mint), A164(port), A135(tank)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.181 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.004 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.201, affine_nobias=0.118, logit=0.667, mean_task=0.704, mean_wiki=0.673, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.201 | 0.105 | 0.064 | 15.110 | 15.857 |
| affine_nobias | 0.118 | 0.089 | 0.139 | 12.614 | 12.931 |
| logit | 0.667 | 0.667 | 0.944 | 10.613 | 10.746 |
| mean_task | 0.704 | 0.704 | 0.951 | 10.806 | 10.826 |
| mean_wiki | 0.673 | 0.673 | 0.944 | 10.857 | 10.902 |
| tuned | 0.553 | 0.552 | 0.904 | 8.482 | 8.465 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -17.13 | -17.26 | 0.13 [-0.84, 1.05] | 0.01 [-0.01, 0.03] | -5.97 [-6.54, -5.43] | -0.01 [-0.04, 0.02] |
| affine_nobias | -14.33 | -14.78 | 0.45 [-0.34, 1.23] | 0.01 [-0.01, 0.03] | -3.17 [-3.62, -2.71] | -0.01 [-0.04, 0.02] |
| logit | -11.16 | -12.94 | 1.78 [1.40, 2.15] | 0.02 [0.01, 0.03] | - | - |
| mean_task | -11.12 | -13.07 | 1.96 [1.82, 2.09] | 0.10 [0.04, 0.16] | 0.04 [-0.19, 0.28] | 0.08 [0.03, 0.14] |
| mean_wiki | -11.19 | -13.24 | 2.05 [1.68, 2.39] | 0.02 [0.01, 0.04] | -0.03 [-0.16, 0.09] | 0.00 [-0.00, 0.00] |
| tuned | -10.39 | -10.60 | 0.21 [-0.37, 0.83] | 0.02 [0.01, 0.04] | 0.77 [0.50, 1.02] | -0.00 [-0.01, 0.01] |

- order_mu_then_affine[mean_task]: mu_share=-0.037, affine_share=0.503, remainder=0.201
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.472, remainder=0.201
- order_affine_then_mu: affine_share=0.549, mu_share=-0.083, remainder=0.201

**repeat** E: affine=0.209, affine_nobias=0.122, logit=0.671, mean_task=0.731, mean_wiki=0.679, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.209 | 0.095 | 0.002 | 16.927 | 16.854 |
| affine_nobias | 0.122 | 0.033 | 0.046 | 13.493 | 13.525 |
| logit | 0.671 | 0.671 | 0.946 | 12.873 | 12.878 |
| mean_task | 0.731 | 0.731 | 0.963 | 14.339 | 14.232 |
| mean_wiki | 0.679 | 0.679 | 0.947 | 12.353 | 12.300 |
| tuned | 0.553 | 0.552 | 0.931 | 11.444 | 11.474 |

- order_mu_then_affine[mean_task]: mu_share=-0.061, affine_share=0.522, remainder=0.209
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.469, remainder=0.209
- order_affine_then_mu: affine_share=0.548, mu_share=-0.087, remainder=0.209

## 문항 집합: common_correct (문항 32, 영어 단어 30)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.344 | [-0.064, 0.643] | - | - | 0.355 |
| mean_task | 0.161 | [-0.250, 0.540] | -0.184 | [-0.653, 0.346] | 0.597 |
| mean_wiki | 0.331 | [-0.062, 0.631] | -0.013 | [-0.194, 0.190] | 0.343 |
| affine | -0.078 | [-0.493, 0.362] | -0.422 | [-0.924, 0.165] | -0.079 |
| affine_nobias | -0.081 | [-0.520, 0.370] | -0.425 | [-0.937, 0.154] | -0.082 |
| tuned | -0.041 | [-0.369, 0.308] | -0.386 | [-0.708, 0.056] | -0.042 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.919, 평균 I_en(영어 입력) = 5.238, I_en > I 비율 = 0.875, Wilcoxon p = 6.9e-07. I > 0 비율 = 0.562
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 고유어 | 10 | -0.515 | 0.384 | -0.782 | 0.701 | 0.303 | -0.017 | -0.235 |
| 한자어 | 12 | 1.629 | 0.368 | 0.312 | 0.280 | -0.224 | 0.035 | -0.150 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.972 | Y |
| s_logit | 0.968 | Y |
| s_mean_task | 0.074 | N |
| s_mean_wiki | 0.958 | Y |
| s_affine | 0.992 | Y |
| s_affine_nobias | 0.991 | Y |
| s_tuned | 0.979 | Y |

템플릿별 lens 순위: T1: mean_wiki > logit > mean_task > tuned > affine_nobias > affine; T2: mean_wiki > logit > mean_task > affine > affine_nobias > tuned; T3: logit > mean_wiki > mean_task > affine_nobias > affine > tuned; T4: mean_wiki > logit > mean_task > tuned > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A099(ear), A116(plane), A190(duck), A184(bowl), A203(pupil), A205(match), A141(kid), A157(lid)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A034(cell), A038(pit), A095(term), A081(diamond), A023(rock), A096(vessel), A135(tank)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.195 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.104 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.201, affine_nobias=0.118, logit=0.667, mean_task=0.703, mean_wiki=0.672, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.201 | 0.105 | 0.064 | 15.555 | 16.382 |
| affine_nobias | 0.118 | 0.089 | 0.139 | 13.057 | 13.558 |
| logit | 0.667 | 0.667 | 0.944 | 10.933 | 11.100 |
| mean_task | 0.703 | 0.703 | 0.950 | 11.213 | 11.293 |
| mean_wiki | 0.672 | 0.672 | 0.944 | 11.194 | 11.279 |
| tuned | 0.553 | 0.552 | 0.905 | 8.865 | 8.997 |

단어 단위 (번역, ℳ 평균 log 확률). gap = 영어 단어 − 정답 첫 토큰, spec = 영어 단어(입력어) − 영어 단어(대조어). Δ는 logit lens 대비, [95% CI]는 문항 bootstrap

| lens | 영어 단어 | 정답 | gap | spec | Δ 영어 단어 | Δ spec |
|---|---|---|---|---|---|---|
| affine | -16.84 | -17.29 | 0.45 [-0.53, 1.50] | -0.00 [-0.02, 0.02] | -5.55 [-6.16, -4.97] | -0.02 [-0.05, 0.01] |
| affine_nobias | -14.08 | -14.80 | 0.71 [-0.15, 1.61] | 0.00 [-0.02, 0.02] | -2.79 [-3.23, -2.31] | -0.02 [-0.05, 0.02] |
| logit | -11.29 | -12.74 | 1.45 [1.03, 1.86] | 0.02 [0.00, 0.04] | - | - |
| mean_task | -11.08 | -13.04 | 1.95 [1.81, 2.12] | 0.11 [0.04, 0.20] | 0.21 [-0.07, 0.50] | 0.09 [0.03, 0.16] |
| mean_wiki | -11.28 | -13.07 | 1.79 [1.42, 2.20] | 0.02 [0.00, 0.04] | 0.02 [-0.10, 0.13] | -0.00 [-0.00, 0.00] |
| tuned | -10.38 | -10.53 | 0.15 [-0.41, 0.71] | 0.02 [-0.00, 0.04] | 0.91 [0.64, 1.22] | -0.00 [-0.02, 0.01] |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.502, remainder=0.201
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.471, remainder=0.201
- order_affine_then_mu: affine_share=0.548, mu_share=-0.083, remainder=0.201

**repeat** E: affine=0.209, affine_nobias=0.122, logit=0.670, mean_task=0.730, mean_wiki=0.678, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.209 | 0.094 | 0.002 | 16.956 | 16.886 |
| affine_nobias | 0.122 | 0.033 | 0.046 | 13.523 | 13.532 |
| logit | 0.670 | 0.670 | 0.946 | 12.892 | 12.891 |
| mean_task | 0.730 | 0.730 | 0.963 | 14.343 | 14.205 |
| mean_wiki | 0.678 | 0.678 | 0.947 | 12.368 | 12.317 |
| tuned | 0.553 | 0.552 | 0.931 | 11.465 | 11.487 |

- order_mu_then_affine[mean_task]: mu_share=-0.060, affine_share=0.522, remainder=0.209
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.470, remainder=0.209
- order_affine_then_mu: affine_share=0.548, mu_share=-0.087, remainder=0.209
