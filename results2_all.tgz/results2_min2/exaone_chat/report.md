# LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct

중간 층 ℳ = 8–22 (전체 30층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9902971497877502,
 "final_layer_max_abs_dlogp": 0.05742514133453369,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=8: R²=0.459 (λ=0.1), ℓ=9: R²=0.476 (λ=0.1), ℓ=10: R²=0.488 (λ=0.1), ℓ=11: R²=0.490 (λ=0.1), ℓ=12: R²=0.493 (λ=0.1), ℓ=13: R²=0.501 (λ=0.1), ℓ=14: R²=0.509 (λ=0.1), ℓ=15: R²=0.516 (λ=0.1), ℓ=16: R²=0.525 (λ=0.1), ℓ=17: R²=0.533 (λ=0.1), ℓ=18: R²=0.538 (λ=0.1), ℓ=19: R²=0.552 (λ=0.1), ℓ=20: R²=0.563 (λ=0.1), ℓ=21: R²=0.576 (λ=0.1), ℓ=22: R²=0.590 (λ=0.1)

## 문항 집합: own_correct (문항 43, 영어 단어 41)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.111 | [-0.245, 0.430] | - | - | 0.115 |
| mean_task | 0.222 | [-0.139, 0.479] | 0.110 | [-0.336, 0.503] | 0.807 |
| mean_wiki | 0.116 | [-0.226, 0.449] | 0.004 | [-0.125, 0.157] | 0.120 |
| affine | -0.089 | [-0.384, 0.268] | -0.201 | [-0.639, 0.298] | -0.091 |
| affine_nobias | -0.111 | [-0.415, 0.240] | -0.222 | [-0.639, 0.261] | -0.113 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.702, 평균 I_en(영어 입력) = 4.585, I_en > I 비율 = 0.907, Wilcoxon p = 2.3e-09. I > 0 비율 = 0.581
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.969 | Y |
| s_logit | 0.971 | Y |
| s_mean_task | 0.078 | N |
| s_mean_wiki | 0.965 | Y |
| s_affine | 0.991 | Y |
| s_affine_nobias | 0.992 | Y |

템플릿별 lens 순위: T1: mean_task > logit > mean_wiki > affine_nobias > affine; T2: mean_task > mean_wiki > logit > affine > affine_nobias; T3: mean_task > logit > mean_wiki > affine_nobias > affine; T4: mean_task > logit > mean_wiki > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A092(staff), A051(deck), A099(ear), A163(corn), A116(plane), A190(duck), A184(bowl), A181(drone)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A034(cell), A095(term), A038(pit), A081(diamond), A036(mint), A164(port), A135(tank)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.181 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.004 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.201, affine_nobias=0.118, logit=0.667, mean_task=0.704, mean_wiki=0.673
- order_mu_then_affine[mean_task]: mu_share=-0.037, affine_share=0.503, remainder=0.201
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.472, remainder=0.201
- order_affine_then_mu: affine_share=0.549, mu_share=-0.083, remainder=0.201

**repeat** E: affine=0.209, affine_nobias=0.122, logit=0.671, mean_task=0.731, mean_wiki=0.679
- order_mu_then_affine[mean_task]: mu_share=-0.061, affine_share=0.522, remainder=0.209
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.469, remainder=0.209
- order_affine_then_mu: affine_share=0.548, mu_share=-0.087, remainder=0.209

## 문항 집합: common_correct (문항 32, 영어 단어 30)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.344 | [-0.064, 0.643] | - | - | 0.355 |
| mean_task | 0.161 | [-0.250, 0.540] | -0.184 | [-0.653, 0.346] | 0.597 |
| mean_wiki | 0.331 | [-0.062, 0.631] | -0.013 | [-0.194, 0.190] | 0.343 |
| affine | -0.078 | [-0.493, 0.362] | -0.422 | [-0.924, 0.165] | -0.079 |
| affine_nobias | -0.081 | [-0.520, 0.370] | -0.425 | [-0.937, 0.154] | -0.082 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.919, 평균 I_en(영어 입력) = 5.238, I_en > I 비율 = 0.875, Wilcoxon p = 6.9e-07. I > 0 비율 = 0.562
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.972 | Y |
| s_logit | 0.968 | Y |
| s_mean_task | 0.074 | N |
| s_mean_wiki | 0.958 | Y |
| s_affine | 0.992 | Y |
| s_affine_nobias | 0.991 | Y |

템플릿별 lens 순위: T1: mean_wiki > logit > mean_task > affine_nobias > affine; T2: mean_wiki > logit > mean_task > affine > affine_nobias; T3: logit > mean_wiki > mean_task > affine_nobias > affine; T4: mean_wiki > logit > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A099(ear), A116(plane), A190(duck), A184(bowl), A203(pupil), A205(match), A141(kid), A157(lid)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A034(cell), A038(pit), A095(term), A081(diamond), A023(rock), A096(vessel), A135(tank)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.195 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.104 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.201, affine_nobias=0.118, logit=0.667, mean_task=0.703, mean_wiki=0.672
- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.502, remainder=0.201
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.471, remainder=0.201
- order_affine_then_mu: affine_share=0.548, mu_share=-0.083, remainder=0.201

**repeat** E: affine=0.209, affine_nobias=0.122, logit=0.670, mean_task=0.730, mean_wiki=0.678
- order_mu_then_affine[mean_task]: mu_share=-0.060, affine_share=0.522, remainder=0.209
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.470, remainder=0.209
- order_affine_then_mu: affine_share=0.548, mu_share=-0.087, remainder=0.209
