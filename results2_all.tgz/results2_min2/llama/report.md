# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9884778653729533,
 "final_layer_max_abs_dlogp": 0.05453360080718994,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.500 (λ=1), ℓ=8: R²=0.502 (λ=1), ℓ=9: R²=0.508 (λ=1), ℓ=10: R²=0.516 (λ=1), ℓ=11: R²=0.521 (λ=1), ℓ=12: R²=0.533 (λ=1), ℓ=13: R²=0.546 (λ=0.1), ℓ=14: R²=0.568 (λ=0.1), ℓ=15: R²=0.584 (λ=0.1), ℓ=16: R²=0.604 (λ=0.1), ℓ=17: R²=0.616 (λ=0.1), ℓ=18: R²=0.623 (λ=0.1), ℓ=19: R²=0.632 (λ=0.1), ℓ=20: R²=0.647 (λ=0.1), ℓ=21: R²=0.662 (λ=0.1)

## 문항 집합: own_correct (문항 48, 영어 단어 45)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.248 | [-0.078, 0.517] | - | - | 0.262 |
| mean_task | 0.223 | [-0.099, 0.489] | -0.025 | [-0.175, 0.143] | 0.237 |
| mean_wiki | 0.221 | [-0.116, 0.497] | -0.027 | [-0.100, 0.043] | 0.233 |
| affine | 0.126 | [-0.179, 0.380] | -0.122 | [-0.358, 0.097] | 0.136 |
| affine_nobias | 0.135 | [-0.166, 0.401] | -0.114 | [-0.338, 0.102] | 0.147 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 1.037, 평균 I_en(영어 입력) = 6.257, I_en > I 비율 = 0.938, Wilcoxon p = 9.9e-14. I > 0 비율 = 0.667
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.910 | Y |
| s_logit | 0.989 | Y |
| s_mean_task | 0.981 | Y |
| s_mean_wiki | 0.989 | Y |
| s_affine | 0.946 | Y |
| s_affine_nobias | 0.919 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > affine > affine_nobias; T3: mean_wiki > logit > mean_task > affine > affine_nobias; T4: mean_wiki > logit > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A006(palm), A057(glasses), A131(tie), A157(lid), A159(spine), A096(vessel)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A122(mold), A056(game), A084(interest), A052(digit), A078(bar), A026(star), A002(fall)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.130 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.006 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.435, affine_nobias=0.353, logit=0.940, mean_task=0.954, mean_wiki=0.946
- order_mu_then_affine[mean_task]: mu_share=-0.014, affine_share=0.518, remainder=0.435
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.510, remainder=0.435
- order_affine_then_mu: affine_share=0.587, mu_share=-0.082, remainder=0.435

**repeat** E: affine=0.394, affine_nobias=0.270, logit=0.927, mean_task=0.928, mean_wiki=0.933
- order_mu_then_affine[mean_task]: mu_share=-0.000, affine_share=0.534, remainder=0.394
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.539, remainder=0.394
- order_affine_then_mu: affine_share=0.657, mu_share=-0.124, remainder=0.394

## 문항 집합: common_correct (문항 32, 영어 단어 30)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.319 | [-0.076, 0.623] | - | - | 0.339 |
| mean_task | 0.252 | [-0.136, 0.559] | -0.067 | [-0.302, 0.158] | 0.268 |
| mean_wiki | 0.292 | [-0.100, 0.602] | -0.027 | [-0.144, 0.083] | 0.310 |
| affine | 0.158 | [-0.236, 0.516] | -0.161 | [-0.444, 0.124] | 0.170 |
| affine_nobias | 0.195 | [-0.190, 0.551] | -0.124 | [-0.401, 0.164] | 0.213 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 1.036, 평균 I_en(영어 입력) = 5.818, I_en > I 비율 = 0.906, Wilcoxon p = 6.5e-09. I > 0 비율 = 0.656
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.896 | Y |
| s_logit | 0.988 | Y |
| s_mean_task | 0.986 | Y |
| s_mean_wiki | 0.990 | Y |
| s_affine | 0.958 | Y |
| s_affine_nobias | 0.928 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > affine > affine_nobias; T3: mean_wiki > logit > mean_task > affine_nobias > affine; T4: logit > mean_wiki > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A057(glasses), A157(lid), A190(duck), A096(vessel), A099(ear), A014(key)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A026(star), A002(fall), A034(cell), A203(pupil), A095(term), A206(letter), A081(diamond)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.035 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.304 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.438, affine_nobias=0.352, logit=0.939, mean_task=0.955, mean_wiki=0.946
- order_mu_then_affine[mean_task]: mu_share=-0.016, affine_share=0.518, remainder=0.438
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.508, remainder=0.438
- order_affine_then_mu: affine_share=0.587, mu_share=-0.086, remainder=0.438

**repeat** E: affine=0.393, affine_nobias=0.268, logit=0.927, mean_task=0.928, mean_wiki=0.933
- order_mu_then_affine[mean_task]: mu_share=-0.001, affine_share=0.535, remainder=0.393
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.539, remainder=0.393
- order_affine_then_mu: affine_share=0.660, mu_share=-0.126, remainder=0.393
