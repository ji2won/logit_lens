# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9884778653729533,
 "final_layer_max_abs_dlogp": 0.05453360080718994,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.531 (λ=1), ℓ=8: R²=0.534 (λ=1), ℓ=9: R²=0.539 (λ=1), ℓ=10: R²=0.546 (λ=1), ℓ=11: R²=0.550 (λ=1), ℓ=12: R²=0.561 (λ=1), ℓ=13: R²=0.574 (λ=1), ℓ=14: R²=0.591 (λ=1), ℓ=15: R²=0.604 (λ=0.1), ℓ=16: R²=0.631 (λ=0.1), ℓ=17: R²=0.644 (λ=0.1), ℓ=18: R²=0.653 (λ=0.1), ℓ=19: R²=0.662 (λ=0.1), ℓ=20: R²=0.679 (λ=0.1), ℓ=21: R²=0.692 (λ=0.1)

## 문항 집합: own_correct (문항 43, 영어 단어 40)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.177 | [-0.157, 0.481] | - | - | 0.186 |
| mean_task | 0.152 | [-0.210, 0.453] | -0.025 | [-0.200, 0.159] | 0.161 |
| mean_wiki | 0.158 | [-0.178, 0.473] | -0.018 | [-0.094, 0.058] | 0.167 |
| affine | 0.147 | [-0.182, 0.427] | -0.030 | [-0.308, 0.224] | 0.161 |
| affine_nobias | 0.126 | [-0.204, 0.409] | -0.050 | [-0.328, 0.212] | 0.139 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.962, 평균 I_en(영어 입력) = 6.309, I_en > I 비율 = 0.953, Wilcoxon p = 1.1e-12. I > 0 비율 = 0.674
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.907 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.981 | Y |
| s_mean_wiki | 0.990 | Y |
| s_affine | 0.918 | Y |
| s_affine_nobias | 0.910 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > affine > affine_nobias; T3: mean_wiki > logit > mean_task > affine > affine_nobias; T4: mean_wiki > affine > affine_nobias > logit > mean_task

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A057(glasses), A006(palm), A096(vessel), A190(duck), A014(key), A165(sound)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A122(mold), A056(game), A084(interest), A052(digit), A078(bar), A026(star), A002(fall)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.084 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.046 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.210, affine_nobias=0.199, logit=0.939, mean_task=0.954, mean_wiki=0.945
- order_mu_then_affine[mean_task]: mu_share=-0.014, affine_share=0.744, remainder=0.210
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.736, remainder=0.210
- order_affine_then_mu: affine_share=0.740, mu_share=-0.010, remainder=0.210

**repeat** E: affine=0.056, affine_nobias=0.049, logit=0.928, mean_task=0.928, mean_wiki=0.933
- order_mu_then_affine[mean_task]: mu_share=-0.000, affine_share=0.872, remainder=0.056
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.877, remainder=0.056
- order_affine_then_mu: affine_share=0.879, mu_share=-0.007, remainder=0.056

## 문항 집합: common_correct (문항 24, 영어 단어 23)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.242 | [-0.222, 0.646] | - | - | 0.259 |
| mean_task | 0.214 | [-0.267, 0.654] | -0.029 | [-0.338, 0.238] | 0.229 |
| mean_wiki | 0.228 | [-0.251, 0.638] | -0.014 | [-0.188, 0.112] | 0.243 |
| affine | 0.083 | [-0.370, 0.545] | -0.159 | [-0.474, 0.096] | 0.091 |
| affine_nobias | 0.029 | [-0.419, 0.489] | -0.213 | [-0.545, 0.059] | 0.032 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.796, 평균 I_en(영어 입력) = 6.109, I_en > I 비율 = 0.917, Wilcoxon p = 6e-07. I > 0 비율 = 0.625
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.884 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.985 | Y |
| s_mean_wiki | 0.992 | Y |
| s_affine | 0.932 | Y |
| s_affine_nobias | 0.935 | Y |

템플릿별 lens 순위: T1: logit > mean_task > mean_wiki > affine > affine_nobias; T2: mean_wiki > mean_task > logit > affine > affine_nobias; T3: mean_wiki > logit > affine_nobias > mean_task > affine; T4: mean_wiki > logit > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A096(vessel), A099(ear), A014(key), A015(letter), A127(rocket), A116(plane)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A026(star), A203(pupil), A034(cell), A095(term), A141(kid), A205(match), A023(rock)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.071 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.361 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.203, affine_nobias=0.193, logit=0.939, mean_task=0.956, mean_wiki=0.945
- order_mu_then_affine[mean_task]: mu_share=-0.017, affine_share=0.752, remainder=0.203
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.742, remainder=0.203
- order_affine_then_mu: affine_share=0.745, mu_share=-0.010, remainder=0.203

**repeat** E: affine=0.056, affine_nobias=0.049, logit=0.927, mean_task=0.929, mean_wiki=0.932
- order_mu_then_affine[mean_task]: mu_share=-0.002, affine_share=0.873, remainder=0.056
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.876, remainder=0.056
- order_affine_then_mu: affine_share=0.879, mu_share=-0.007, remainder=0.056
