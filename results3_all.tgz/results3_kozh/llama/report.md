# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9884778653729533,
 "final_layer_max_abs_dlogp": 0.054591476917266846,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.531 (λ=1), ℓ=8: R²=0.534 (λ=1), ℓ=9: R²=0.539 (λ=1), ℓ=10: R²=0.546 (λ=1), ℓ=11: R²=0.550 (λ=1), ℓ=12: R²=0.561 (λ=1), ℓ=13: R²=0.574 (λ=1), ℓ=14: R²=0.591 (λ=1), ℓ=15: R²=0.604 (λ=0.1), ℓ=16: R²=0.631 (λ=0.1), ℓ=17: R²=0.644 (λ=0.1), ℓ=18: R²=0.653 (λ=0.1), ℓ=19: R²=0.662 (λ=0.1), ℓ=20: R²=0.679 (λ=0.1), ℓ=21: R²=0.692 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=7: 9.00→2.24, ℓ=8: 8.92→2.22, ℓ=9: 8.95→2.16, ℓ=10: 8.94→2.12, ℓ=11: 8.86→2.08, ℓ=12: 8.68→2.01, ℓ=13: 8.42→1.92, ℓ=14: 8.20→1.80, ℓ=15: 7.84→1.64, ℓ=16: 7.18→1.48, ℓ=17: 6.84→1.38, ℓ=18: 6.54→1.31, ℓ=19: 6.34→1.23, ℓ=20: 5.97→1.13, ℓ=21: 5.63→1.03

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: ' '×2480, '1'×545, '大'×353, ' 기'×110, '（'×76, ' �'×74, '\xa0'×65, ' ('×58, ' 사'×55, '的'×41, '球'×41, '人'×39
- affine_nobias: ' '×2432, '1'×544, '大'×319, ' 연'×114, ' 기'×105, ' 사'×70, ' �'×70, ' ('×63, '一'×51, ' 아'×46, '\xa0'×46, ' �'×45
- logit: 'afi'×267, 'anzi'×180, 'uada'×154, 'onium'×145, 'wis'×144, ' ders'×121, 'arious'×113, 'pert'×102, 'omat'×94, 'stro'×87, 'vir'×82, 'ーズ'×75
- mean_task: 'upo'×113, ' golf'×49, 'jian'×48, 'olina'×44, 'wards'×42, ' eyes'×38, ' plants'×35, ' fingers'×30, ' storyline'×29, ' \u200b\u200b'×28, ' magazine'×28, ' waves'×28
- mean_wiki: 'onium'×258, 'afi'×190, 'ady'×133, 'quiv'×98, 'ruba'×83, 'allon'×67, 'arious'×60, 'lei'×58, 'IFS'×58, 'ož'×57, ' Platt'×52, 'ellig'×50
- tuned: '�'×529, '�'×322, '余'×185, '�'×182, 'K'×166, '�'×156, '�'×115, '�'×102, '이'×100, ' 공'×91, ' 두'×87, '人'×77

## 문항 집합: own_correct (문항 43, 영어 단어 40)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.177 | [-0.157, 0.481] | - | - | 0.186 |
| mean_task | 0.152 | [-0.210, 0.453] | -0.025 | [-0.200, 0.159] | 0.161 |
| mean_wiki | 0.158 | [-0.178, 0.473] | -0.018 | [-0.094, 0.058] | 0.167 |
| affine | 0.147 | [-0.182, 0.427] | -0.030 | [-0.308, 0.224] | 0.161 |
| affine_nobias | 0.126 | [-0.204, 0.409] | -0.050 | [-0.328, 0.212] | 0.139 |
| tuned | 0.161 | [-0.141, 0.418] | -0.016 | [-0.223, 0.167] | 0.170 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.962, 평균 I_en(영어 입력) = 6.309, I_en > I 비율 = 0.953, Wilcoxon p = 1.1e-12. I > 0 비율 = 0.674
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.907 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.981 | Y |
| s_mean_wiki | 0.990 | Y |
| s_affine | 0.918 | Y |
| s_affine_nobias | 0.910 | Y |
| s_tuned | 0.985 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > tuned > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T3: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T4: mean_wiki > affine > affine_nobias > logit > tuned > mean_task

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A057(glasses), A006(palm), A096(vessel), A190(duck), A014(key), A165(sound)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A122(mold), A056(game), A084(interest), A052(digit), A078(bar), A026(star), A002(fall)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.084 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.046 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.210, affine_nobias=0.199, logit=0.939, mean_task=0.954, mean_wiki=0.945, tuned=0.380

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.210 | 0.153 | 0.581 | 7.733 | 7.349 |
| affine_nobias | 0.199 | 0.153 | 0.606 | 7.439 | 6.994 |
| logit | 0.939 | 0.940 | 0.876 | 9.364 | 9.487 |
| mean_task | 0.954 | 0.955 | 0.913 | 10.963 | 10.730 |
| mean_wiki | 0.945 | 0.946 | 0.871 | 9.642 | 9.636 |
| tuned | 0.380 | 0.369 | 0.922 | 7.075 | 7.235 |

- order_mu_then_affine[mean_task]: mu_share=-0.014, affine_share=0.744, remainder=0.210
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.736, remainder=0.210
- order_affine_then_mu: affine_share=0.740, mu_share=-0.010, remainder=0.210

**repeat** E: affine=0.056, affine_nobias=0.049, logit=0.928, mean_task=0.928, mean_wiki=0.933, tuned=0.370

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.056 | 0.020 | 0.530 | 6.290 | 5.993 |
| affine_nobias | 0.049 | 0.023 | 0.624 | 5.912 | 5.452 |
| logit | 0.928 | 0.928 | 0.854 | 10.562 | 10.910 |
| mean_task | 0.928 | 0.929 | 0.868 | 10.802 | 11.244 |
| mean_wiki | 0.933 | 0.933 | 0.846 | 10.661 | 11.020 |
| tuned | 0.370 | 0.362 | 0.906 | 5.832 | 6.206 |

- order_mu_then_affine[mean_task]: mu_share=-0.000, affine_share=0.872, remainder=0.056
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.877, remainder=0.056
- order_affine_then_mu: affine_share=0.879, mu_share=-0.007, remainder=0.056

## 문항 집합: common_correct (문항 24, 영어 단어 23)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.242 | [-0.222, 0.646] | - | - | 0.259 |
| mean_task | 0.214 | [-0.267, 0.654] | -0.029 | [-0.338, 0.238] | 0.229 |
| mean_wiki | 0.228 | [-0.251, 0.638] | -0.014 | [-0.188, 0.112] | 0.243 |
| affine | 0.083 | [-0.370, 0.545] | -0.159 | [-0.474, 0.096] | 0.091 |
| affine_nobias | 0.029 | [-0.419, 0.489] | -0.213 | [-0.545, 0.059] | 0.032 |
| tuned | 0.153 | [-0.307, 0.589] | -0.089 | [-0.369, 0.155] | 0.164 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.796, 평균 I_en(영어 입력) = 6.109, I_en > I 비율 = 0.917, Wilcoxon p = 6e-07. I > 0 비율 = 0.625
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.884 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.985 | Y |
| s_mean_wiki | 0.992 | Y |
| s_affine | 0.932 | Y |
| s_affine_nobias | 0.935 | Y |
| s_tuned | 0.982 | Y |

템플릿별 lens 순위: T1: logit > mean_task > mean_wiki > tuned > affine > affine_nobias; T2: mean_wiki > mean_task > logit > tuned > affine > affine_nobias; T3: mean_wiki > logit > affine_nobias > mean_task > affine > tuned; T4: mean_wiki > logit > mean_task > affine > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A096(vessel), A099(ear), A014(key), A015(letter), A127(rocket), A116(plane)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A026(star), A203(pupil), A034(cell), A095(term), A141(kid), A205(match), A023(rock)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.071 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.361 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.203, affine_nobias=0.193, logit=0.939, mean_task=0.956, mean_wiki=0.945, tuned=0.374

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.203 | 0.149 | 0.580 | 7.866 | 7.689 |
| affine_nobias | 0.193 | 0.149 | 0.606 | 7.575 | 7.294 |
| logit | 0.939 | 0.939 | 0.875 | 9.339 | 9.516 |
| mean_task | 0.956 | 0.957 | 0.914 | 11.052 | 10.871 |
| mean_wiki | 0.945 | 0.946 | 0.870 | 9.604 | 9.689 |
| tuned | 0.374 | 0.363 | 0.922 | 7.222 | 7.453 |

- order_mu_then_affine[mean_task]: mu_share=-0.017, affine_share=0.752, remainder=0.203
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.742, remainder=0.203
- order_affine_then_mu: affine_share=0.745, mu_share=-0.010, remainder=0.203

**repeat** E: affine=0.056, affine_nobias=0.049, logit=0.927, mean_task=0.929, mean_wiki=0.932, tuned=0.373

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.056 | 0.021 | 0.531 | 6.581 | 6.356 |
| affine_nobias | 0.049 | 0.023 | 0.624 | 6.178 | 5.846 |
| logit | 0.927 | 0.928 | 0.853 | 10.759 | 10.981 |
| mean_task | 0.929 | 0.930 | 0.869 | 10.954 | 11.322 |
| mean_wiki | 0.932 | 0.933 | 0.846 | 10.804 | 11.243 |
| tuned | 0.373 | 0.365 | 0.906 | 6.150 | 6.470 |

- order_mu_then_affine[mean_task]: mu_share=-0.002, affine_share=0.873, remainder=0.056
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.876, remainder=0.056
- order_affine_then_mu: affine_share=0.879, mu_share=-0.007, remainder=0.056
