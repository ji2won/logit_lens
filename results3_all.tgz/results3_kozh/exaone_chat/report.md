# LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct

중간 층 ℳ = 8–22 (전체 30층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9902971497877502,
 "final_layer_max_abs_dlogp": 0.05726444721221924,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=8: R²=0.481 (λ=0.1), ℓ=9: R²=0.493 (λ=0.1), ℓ=10: R²=0.506 (λ=0.1), ℓ=11: R²=0.510 (λ=0.1), ℓ=12: R²=0.513 (λ=0.1), ℓ=13: R²=0.520 (λ=0.1), ℓ=14: R²=0.528 (λ=0.1), ℓ=15: R²=0.534 (λ=0.1), ℓ=16: R²=0.542 (λ=0.1), ℓ=17: R²=0.549 (λ=0.1), ℓ=18: R²=0.553 (λ=0.1), ℓ=19: R²=0.565 (λ=0.1), ℓ=20: R²=0.576 (λ=0.1), ℓ=21: R²=0.589 (λ=0.1), ℓ=22: R²=0.603 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=8: 8.49→2.10, ℓ=9: 8.39→2.04, ℓ=10: 8.32→1.98, ℓ=11: 8.44→1.96, ℓ=12: 8.37→1.95, ℓ=13: 8.41→1.92, ℓ=14: 8.35→1.86, ℓ=15: 8.14→1.83, ℓ=16: 8.12→1.79, ℓ=17: 8.10→1.78, ℓ=18: 7.93→1.75, ℓ=19: 7.54→1.67, ℓ=20: 7.31→1.57, ℓ=21: 7.01→1.51, ℓ=22: 6.66→1.44

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: '\n'×5600, '�'×114, '大'×100, '人'×4, '�'×2
- affine_nobias: '\n'×5459, '�'×220, '大'×132, '人'×6, '�'×2, '�'×1
- logit: ' chuckled'×1380, ' respectfully'×655, ' —.'×318, 'onas'×253, 'icho'×228, ' sweet'×194, 'ucc'×192, ' debatable'×187, ' Philippe'×167, ' %/'×163, ' standout'×158, 'år'×147
- mean_task: ' gamb'×187, ' Jain'×153, 'yth'×147, ' 겠다는'×142, 'grav'×119, ' trailing'×115, ' Lay'×98, '�'×97, ' 완'×97, '욕장'×94, 'loyd'×90, 'idis'×89
- mean_wiki: ' chuckled'×683, 'icho'×627, ' infiltr'×517, '듬해'×427, ' respectfully'×421, 'ivas'×412, ' %/'×404, ' outnumber'×388, ' Matth'×387, ' prolifer'×194, '[|endofturn|]'×191, 'lon'×173
- tuned: ' '×776, '[|endofturn|]'×416, '('×388, ' 개요'×388, '현'×386, 'N'×317, '�'×305, '다음'×278, 'yes'×258, '9'×257, '�'×255, 'icho'×207

## 문항 집합: own_correct (문항 31, 영어 단어 30)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.002 | [-0.429, 0.382] | - | - | 0.002 |
| mean_task | 0.118 | [-0.285, 0.455] | 0.116 | [-0.409, 0.648] | 0.331 |
| mean_wiki | -0.036 | [-0.447, 0.358] | -0.038 | [-0.215, 0.153] | -0.038 |
| affine | -0.124 | [-0.483, 0.232] | -0.125 | [-0.698, 0.488] | -0.127 |
| affine_nobias | -0.077 | [-0.427, 0.271] | -0.079 | [-0.664, 0.568] | -0.079 |
| tuned | -0.153 | [-0.502, 0.210] | -0.155 | [-0.595, 0.316] | -0.158 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.268, 평균 I_en(영어 입력) = 4.169, I_en > I 비율 = 0.871, Wilcoxon p = 3e-06. I > 0 비율 = 0.548
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.962 | Y |
| s_logit | 0.967 | Y |
| s_mean_task | 0.132 | N |
| s_mean_wiki | 0.963 | Y |
| s_affine | 0.983 | Y |
| s_affine_nobias | 0.980 | Y |
| s_tuned | 0.973 | Y |

템플릿별 lens 순위: T1: mean_task > logit > mean_wiki > affine > tuned > affine_nobias; T2: mean_task > mean_wiki > logit > affine_nobias > affine > tuned; T3: mean_task > logit > mean_wiki > affine_nobias > affine > tuned; T4: mean_task > logit > mean_wiki > affine_nobias > tuned > affine

불일치 (logit lens 높음·간섭 낮음): A092(staff), A099(ear), A163(corn), A116(plane), A157(lid), A203(pupil), A205(match), A139(wave)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A038(pit), A095(term), A034(cell), A036(mint), A096(vessel), A023(rock), A164(port)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.127 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.112 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.254, affine_nobias=0.230, logit=0.667, mean_task=0.703, mean_wiki=0.672, tuned=0.536

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.254 | 0.068 | 0.067 | 16.457 | 17.382 |
| affine_nobias | 0.230 | 0.085 | 0.077 | 15.694 | 16.559 |
| logit | 0.667 | 0.667 | 0.944 | 10.933 | 11.082 |
| mean_task | 0.703 | 0.703 | 0.951 | 11.150 | 11.212 |
| mean_wiki | 0.672 | 0.672 | 0.944 | 11.185 | 11.263 |
| tuned | 0.536 | 0.538 | 0.918 | 8.970 | 9.056 |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.449, remainder=0.254
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.419, remainder=0.254
- order_affine_then_mu: affine_share=0.437, mu_share=-0.024, remainder=0.254

**repeat** E: affine=0.210, affine_nobias=0.185, logit=0.671, mean_task=0.730, mean_wiki=0.679, tuned=0.531

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.210 | 0.142 | 0.002 | 16.293 | 16.262 |
| affine_nobias | 0.185 | 0.104 | 0.009 | 14.156 | 13.908 |
| logit | 0.671 | 0.671 | 0.946 | 12.843 | 12.871 |
| mean_task | 0.730 | 0.731 | 0.963 | 14.348 | 14.207 |
| mean_wiki | 0.679 | 0.679 | 0.947 | 12.331 | 12.296 |
| tuned | 0.531 | 0.535 | 0.927 | 11.492 | 11.468 |

- order_mu_then_affine[mean_task]: mu_share=-0.060, affine_share=0.520, remainder=0.210
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.468, remainder=0.210
- order_affine_then_mu: affine_share=0.486, mu_share=-0.025, remainder=0.210

## 문항 집합: common_correct (문항 24, 영어 단어 23)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.237 | [-0.232, 0.638] | - | - | 0.246 |
| mean_task | 0.148 | [-0.307, 0.573] | -0.089 | [-0.619, 0.494] | 0.286 |
| mean_wiki | 0.127 | [-0.356, 0.549] | -0.111 | [-0.358, 0.138] | 0.131 |
| affine | -0.155 | [-0.647, 0.354] | -0.392 | [-1.027, 0.301] | -0.159 |
| affine_nobias | -0.121 | [-0.623, 0.362] | -0.358 | [-1.033, 0.346] | -0.124 |
| tuned | -0.084 | [-0.451, 0.332] | -0.321 | [-0.801, 0.229] | -0.086 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.462, 평균 I_en(영어 입력) = 4.890, I_en > I 비율 = 0.833, Wilcoxon p = 9.1e-05. I > 0 비율 = 0.542
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.969 | Y |
| s_logit | 0.962 | Y |
| s_mean_task | 0.278 | N |
| s_mean_wiki | 0.970 | Y |
| s_affine | 0.983 | Y |
| s_affine_nobias | 0.979 | Y |
| s_tuned | 0.976 | Y |

템플릿별 lens 순위: T1: mean_task > logit > mean_wiki > tuned > affine > affine_nobias; T2: logit > mean_wiki > mean_task > tuned > affine > affine_nobias; T3: logit > mean_wiki > mean_task > affine_nobias > tuned > affine; T4: mean_task > logit > mean_wiki > tuned > affine_nobias > affine

불일치 (logit lens 높음·간섭 낮음): A099(ear), A116(plane), A203(pupil), A205(match), A141(kid), A158(crown), A120(ward), A178(washer)

불일치 (logit lens 낮음·간섭 높음): A127(rocket), A038(pit), A095(term), A034(cell), A023(rock), A096(vessel), A164(port), A001(spring)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.099 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.079 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.254, affine_nobias=0.230, logit=0.667, mean_task=0.702, mean_wiki=0.672, tuned=0.536

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.254 | 0.068 | 0.066 | 16.856 | 17.863 |
| affine_nobias | 0.230 | 0.085 | 0.077 | 16.086 | 17.024 |
| logit | 0.667 | 0.667 | 0.944 | 11.098 | 11.276 |
| mean_task | 0.702 | 0.702 | 0.951 | 11.401 | 11.474 |
| mean_wiki | 0.672 | 0.672 | 0.944 | 11.367 | 11.462 |
| tuned | 0.536 | 0.538 | 0.918 | 9.264 | 9.396 |

- order_mu_then_affine[mean_task]: mu_share=-0.035, affine_share=0.448, remainder=0.254
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.418, remainder=0.254
- order_affine_then_mu: affine_share=0.437, mu_share=-0.024, remainder=0.254

**repeat** E: affine=0.209, affine_nobias=0.184, logit=0.670, mean_task=0.730, mean_wiki=0.678, tuned=0.531

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.209 | 0.142 | 0.003 | 16.146 | 16.155 |
| affine_nobias | 0.184 | 0.104 | 0.009 | 14.015 | 13.785 |
| logit | 0.670 | 0.670 | 0.946 | 12.865 | 12.884 |
| mean_task | 0.730 | 0.730 | 0.962 | 14.353 | 14.193 |
| mean_wiki | 0.678 | 0.678 | 0.947 | 12.339 | 12.287 |
| tuned | 0.531 | 0.535 | 0.927 | 11.478 | 11.455 |

- order_mu_then_affine[mean_task]: mu_share=-0.059, affine_share=0.520, remainder=0.209
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.469, remainder=0.209
- order_affine_then_mu: affine_share=0.486, mu_share=-0.025, remainder=0.209
