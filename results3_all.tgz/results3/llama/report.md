# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9884778653729533,
 "final_layer_max_abs_dlogp": 0.054591476917266846,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.500 (λ=1), ℓ=8: R²=0.502 (λ=1), ℓ=9: R²=0.508 (λ=1), ℓ=10: R²=0.516 (λ=1), ℓ=11: R²=0.521 (λ=1), ℓ=12: R²=0.533 (λ=1), ℓ=13: R²=0.546 (λ=0.1), ℓ=14: R²=0.568 (λ=0.1), ℓ=15: R²=0.584 (λ=0.1), ℓ=16: R²=0.604 (λ=0.1), ℓ=17: R²=0.616 (λ=0.1), ℓ=18: R²=0.623 (λ=0.1), ℓ=19: R²=0.632 (λ=0.1), ℓ=20: R²=0.647 (λ=0.1), ℓ=21: R²=0.662 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=7: 8.99→2.46, ℓ=8: 8.86→2.43, ℓ=9: 8.92→2.38, ℓ=10: 8.88→2.33, ℓ=11: 8.76→2.30, ℓ=12: 8.58→2.21, ℓ=13: 8.32→2.09, ℓ=14: 8.07→1.97, ℓ=15: 7.66→1.80, ℓ=16: 7.00→1.64, ℓ=17: 6.61→1.52, ℓ=18: 6.35→1.45, ℓ=19: 6.06→1.36, ℓ=20: 5.71→1.24, ℓ=21: 5.39→1.14

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: ' '×2902, '1'×268, '大'×202, '\xa0'×141, '小'×107, ' 사'×102, ' 기'×95, ' �'×81, '的'×68, ' 유'×67, ' �'×65, '一'×61
- affine_nobias: ' '×2786, '1'×328, '大'×237, '小'×123, '\xa0'×110, '的'×93, ' 사'×93, ' 기'×93, ' �'×79, 'A'×70, ' �'×61, ' 유'×55
- logit: 'afi'×267, 'anzi'×180, 'uada'×154, 'onium'×145, 'wis'×144, ' ders'×121, 'arious'×113, 'pert'×102, 'omat'×94, 'stro'×87, 'vir'×82, 'ーズ'×75
- mean_task: 'upo'×113, ' golf'×49, 'jian'×48, 'olina'×44, 'wards'×42, ' eyes'×38, ' plants'×35, ' fingers'×30, ' storyline'×29, ' \u200b\u200b'×28, ' magazine'×28, ' waves'×28
- mean_wiki: 'onium'×258, 'afi'×190, 'ady'×133, 'quiv'×98, 'ruba'×83, 'allon'×67, 'arious'×60, 'lei'×58, 'IFS'×58, 'ož'×57, ' Platt'×52, 'ellig'×50
- tuned: ' '×498, '�'×265, '人'×228, '�'×200, '散'×199, '排'×144, '�'×143, '동'×119, '�'×111, ' "'×94, '什'×81, 'K'×79

## 문항 집합: own_correct (문항 43, 영어 단어 40)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.177 | [-0.157, 0.481] | - | - | 0.186 |
| mean_task | 0.152 | [-0.210, 0.453] | -0.025 | [-0.200, 0.159] | 0.161 |
| mean_wiki | 0.158 | [-0.178, 0.473] | -0.018 | [-0.094, 0.058] | 0.167 |
| affine | 0.069 | [-0.255, 0.343] | -0.108 | [-0.361, 0.139] | 0.074 |
| affine_nobias | 0.085 | [-0.233, 0.376] | -0.092 | [-0.339, 0.147] | 0.092 |
| tuned | 0.159 | [-0.146, 0.417] | -0.018 | [-0.232, 0.177] | 0.168 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.962, 평균 I_en(영어 입력) = 6.309, I_en > I 비율 = 0.953, Wilcoxon p = 1.1e-12. I > 0 비율 = 0.674
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.907 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.981 | Y |
| s_mean_wiki | 0.990 | Y |
| s_affine | 0.951 | Y |
| s_affine_nobias | 0.932 | Y |
| s_tuned | 0.984 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > tuned > mean_task > affine > affine_nobias; T2: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T3: mean_wiki > logit > mean_task > tuned > affine > affine_nobias; T4: tuned > mean_wiki > logit > mean_task > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A057(glasses), A006(palm), A096(vessel), A190(duck), A014(key), A165(sound)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A122(mold), A056(game), A084(interest), A052(digit), A078(bar), A026(star), A002(fall)

- mu_share_vs_zipf_en_mean_task: Spearman = -0.084 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.046 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.434, affine_nobias=0.352, logit=0.939, mean_task=0.954, mean_wiki=0.945, tuned=0.380

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.434 | 0.165 | 0.512 | 9.069 | 7.269 |
| affine_nobias | 0.352 | 0.183 | 0.564 | 7.963 | 7.052 |
| logit | 0.939 | 0.940 | 0.876 | 9.364 | 9.487 |
| mean_task | 0.954 | 0.955 | 0.913 | 10.963 | 10.730 |
| mean_wiki | 0.945 | 0.946 | 0.871 | 9.642 | 9.636 |
| tuned | 0.380 | 0.366 | 0.917 | 7.089 | 7.205 |

- order_mu_then_affine[mean_task]: mu_share=-0.014, affine_share=0.519, remainder=0.434
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.511, remainder=0.434
- order_affine_then_mu: affine_share=0.588, mu_share=-0.083, remainder=0.434

**repeat** E: affine=0.393, affine_nobias=0.269, logit=0.928, mean_task=0.928, mean_wiki=0.933, tuned=0.413

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.393 | 0.039 | 0.554 | 8.139 | 6.038 |
| affine_nobias | 0.269 | 0.068 | 0.638 | 6.772 | 5.478 |
| logit | 0.928 | 0.928 | 0.854 | 10.562 | 10.910 |
| mean_task | 0.928 | 0.929 | 0.868 | 10.802 | 11.244 |
| mean_wiki | 0.933 | 0.933 | 0.846 | 10.661 | 11.020 |
| tuned | 0.413 | 0.403 | 0.900 | 5.873 | 6.220 |

- order_mu_then_affine[mean_task]: mu_share=-0.000, affine_share=0.535, remainder=0.393
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.540, remainder=0.393
- order_affine_then_mu: affine_share=0.658, mu_share=-0.124, remainder=0.393

## 문항 집합: common_correct (문항 24, 영어 단어 23)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.242 | [-0.222, 0.646] | - | - | 0.259 |
| mean_task | 0.214 | [-0.267, 0.654] | -0.029 | [-0.338, 0.238] | 0.229 |
| mean_wiki | 0.228 | [-0.251, 0.638] | -0.014 | [-0.188, 0.112] | 0.243 |
| affine | -0.032 | [-0.476, 0.425] | -0.274 | [-0.625, 0.038] | -0.035 |
| affine_nobias | -0.005 | [-0.453, 0.474] | -0.247 | [-0.573, 0.070] | -0.005 |
| tuned | 0.106 | [-0.345, 0.526] | -0.136 | [-0.445, 0.110] | 0.113 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 0.796, 평균 I_en(영어 입력) = 6.109, I_en > I 비율 = 0.917, Wilcoxon p = 6e-07. I > 0 비율 = 0.625
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.884 | Y |
| s_logit | 0.990 | Y |
| s_mean_task | 0.985 | Y |
| s_mean_wiki | 0.992 | Y |
| s_affine | 0.969 | Y |
| s_affine_nobias | 0.940 | Y |
| s_tuned | 0.989 | Y |

템플릿별 lens 순위: T1: logit > mean_task > mean_wiki > tuned > affine > affine_nobias; T2: mean_wiki > mean_task > logit > tuned > affine_nobias > affine; T3: mean_wiki > logit > mean_task > tuned > affine_nobias > affine; T4: mean_wiki > logit > mean_task > tuned > affine > affine_nobias

불일치 (logit lens 높음·간섭 낮음): A001(spring), A140(box), A096(vessel), A099(ear), A014(key), A015(letter), A127(rocket), A116(plane)

불일치 (logit lens 낮음·간섭 높음): A204(plant), A026(star), A203(pupil), A034(cell), A095(term), A141(kid), A205(match), A023(rock)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.071 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.361 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.435, affine_nobias=0.347, logit=0.939, mean_task=0.956, mean_wiki=0.945, tuned=0.376

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.435 | 0.164 | 0.507 | 9.226 | 7.503 |
| affine_nobias | 0.347 | 0.183 | 0.561 | 8.084 | 7.377 |
| logit | 0.939 | 0.939 | 0.875 | 9.339 | 9.516 |
| mean_task | 0.956 | 0.957 | 0.914 | 11.052 | 10.871 |
| mean_wiki | 0.945 | 0.946 | 0.870 | 9.604 | 9.689 |
| tuned | 0.376 | 0.362 | 0.917 | 7.274 | 7.477 |

- order_mu_then_affine[mean_task]: mu_share=-0.017, affine_share=0.521, remainder=0.435
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.510, remainder=0.435
- order_affine_then_mu: affine_share=0.591, mu_share=-0.087, remainder=0.435

**repeat** E: affine=0.395, affine_nobias=0.268, logit=0.927, mean_task=0.929, mean_wiki=0.932, tuned=0.416

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.395 | 0.040 | 0.554 | 8.429 | 6.317 |
| affine_nobias | 0.268 | 0.070 | 0.638 | 7.008 | 5.783 |
| logit | 0.927 | 0.928 | 0.853 | 10.759 | 10.981 |
| mean_task | 0.929 | 0.930 | 0.869 | 10.954 | 11.322 |
| mean_wiki | 0.932 | 0.933 | 0.846 | 10.804 | 11.243 |
| tuned | 0.416 | 0.406 | 0.899 | 6.156 | 6.524 |

- order_mu_then_affine[mean_task]: mu_share=-0.002, affine_share=0.535, remainder=0.395
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.538, remainder=0.395
- order_affine_then_mu: affine_share=0.659, mu_share=-0.126, remainder=0.395
