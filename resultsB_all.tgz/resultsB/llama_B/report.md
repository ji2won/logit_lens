# meta-llama/Llama-3.2-3B

중간 층 ℳ = 7–21 (전체 28층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9950980392156863,
 "final_layer_max_abs_dlogp": 0.04313063621520996,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=7: R²=0.500 (λ=1), ℓ=8: R²=0.502 (λ=1), ℓ=9: R²=0.508 (λ=1), ℓ=10: R²=0.516 (λ=1), ℓ=11: R²=0.521 (λ=1), ℓ=12: R²=0.533 (λ=1), ℓ=13: R²=0.546 (λ=0.1), ℓ=14: R²=0.568 (λ=0.1), ℓ=15: R²=0.584 (λ=0.1), ℓ=16: R²=0.604 (λ=0.1), ℓ=17: R²=0.616 (λ=0.1), ℓ=18: R²=0.623 (λ=0.1), ℓ=19: R²=0.632 (λ=0.1), ℓ=20: R²=0.647 (λ=0.1), ℓ=21: R²=0.662 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=7: 8.99→2.46, ℓ=8: 8.86→2.43, ℓ=9: 8.92→2.38, ℓ=10: 8.88→2.33, ℓ=11: 8.76→2.30, ℓ=12: 8.58→2.21, ℓ=13: 8.32→2.09, ℓ=14: 8.07→1.97, ℓ=15: 7.66→1.80, ℓ=16: 7.00→1.64, ℓ=17: 6.61→1.52, ℓ=18: 6.35→1.45, ℓ=19: 6.06→1.36, ℓ=20: 5.71→1.24, ℓ=21: 5.39→1.14

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: ' '×1996, '1'×142, '\xa0'×124, ' 사'×100, '大'×94, ' ('×68, '人'×60, '的'×44, '小'×44, '一'×38, ' 유'×36, ' 기'×36
- affine_nobias: ' '×1934, '1'×192, '大'×112, ' 사'×96, '人'×74, ' ('×62, '\xa0'×60, '的'×56, '小'×46, '一'×34, '女'×34, ' 유'×33
- logit: 'afi'×205, ' ders'×110, 'anzi'×108, 'uada'×96, 'wis'×86, 'onium'×72, ' Platt'×56, ' electricity'×56, 'stro'×50, ' Gef'×48, 'iger'×46, ' furniture'×44
- mean_task: 'upo'×79, ' wind'×60, ' sleep'×58, ' electricity'×56, ' meetings'×52, ' accident'×48, ' grass'×44, ' night'×44, ' furniture'×44, ' digestion'×44, ' household'×40, ' wife'×40
- mean_wiki: 'afi'×135, 'onium'×132, 'ady'×96, 'allon'×88, 'iger'×67, 'IFS'×56, ' electricity'×54, ' wind'×54, ' sleep'×52, 'quiv'×50, ' Platt'×44, 'ruba'×43
- tuned: ' '×295, '散'×218, '人'×158, '�'×109, '동'×100, '什'×92, '�'×81, '�'×70, '医'×56, ' 공'×52, '电'×52, ' "'×48

## 문항 집합: own_correct (문항 22, 영어 단어 22)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.331 | [-0.157, 0.696] | - | - | 0.361 |
| mean_task | 0.296 | [-0.199, 0.726] | -0.035 | [-0.297, 0.295] | 0.345 |
| mean_wiki | 0.331 | [-0.149, 0.693] | 0.000 | [-0.141, 0.157] | 0.365 |
| affine | 0.148 | [-0.377, 0.569] | -0.183 | [-0.613, 0.237] | 0.169 |
| affine_nobias | 0.092 | [-0.402, 0.538] | -0.239 | [-0.688, 0.216] | 0.105 |
| tuned | 0.083 | [-0.461, 0.559] | -0.248 | [-0.569, 0.089] | 0.100 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 3.805, 평균 I_en(영어 입력) = 0.512, I_en > I 비율 = 0.091, Wilcoxon p = 2.6e-05. I > 0 비율 = 0.955
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 15 | 3.577 | 0.171 | 0.037 | 0.168 | -0.001 | 0.002 | -0.050 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.887 | Y |
| s_logit | 0.949 | Y |
| s_mean_task | 0.833 | Y |
| s_mean_wiki | 0.926 | Y |
| s_affine | 0.863 | Y |
| s_affine_nobias | 0.866 | Y |
| s_tuned | 0.783 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > affine > affine_nobias > mean_task > tuned; T2: mean_task > logit > mean_wiki > affine > affine_nobias > tuned; T3: logit > mean_wiki > mean_task > affine > affine_nobias > tuned; T4: mean_wiki > logit > mean_task > affine > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): B045(household), B066(bride), B055(capacity), B015(apology), B053(distance), B069(cremation), B063(doubt), B105(guidance)

불일치 (logit lens 낮음·간섭 높음): B059(thinking), B117(denial), B111(extinguishing), B083(region), B093(audit), B119(surface), B009(speech), B014(bottle)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.223 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.307 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.437, affine_nobias=0.354, logit=0.943, mean_task=0.955, mean_wiki=0.949, tuned=0.386

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.437 | 0.159 | 0.477 | 8.635 | 6.681 |
| affine_nobias | 0.354 | 0.178 | 0.526 | 7.513 | 6.537 |
| logit | 0.943 | 0.944 | 0.880 | 9.043 | 9.137 |
| mean_task | 0.955 | 0.957 | 0.913 | 11.202 | 10.576 |
| mean_wiki | 0.949 | 0.950 | 0.875 | 9.379 | 9.458 |
| tuned | 0.386 | 0.373 | 0.918 | 6.750 | 6.738 |

- order_mu_then_affine[mean_task]: mu_share=-0.012, affine_share=0.518, remainder=0.437
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.511, remainder=0.437
- order_affine_then_mu: affine_share=0.589, mu_share=-0.083, remainder=0.437

**repeat** E: affine=0.393, affine_nobias=0.271, logit=0.929, mean_task=0.928, mean_wiki=0.936, tuned=0.412

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.393 | 0.040 | 0.549 | 7.891 | 5.840 |
| affine_nobias | 0.271 | 0.071 | 0.633 | 6.545 | 5.384 |
| logit | 0.929 | 0.930 | 0.857 | 10.273 | 10.800 |
| mean_task | 0.928 | 0.929 | 0.869 | 10.607 | 11.248 |
| mean_wiki | 0.936 | 0.937 | 0.851 | 10.336 | 10.793 |
| tuned | 0.412 | 0.401 | 0.901 | 5.488 | 6.045 |

- order_mu_then_affine[mean_task]: mu_share=0.002, affine_share=0.535, remainder=0.393
- order_mu_then_affine[mean_wiki]: mu_share=-0.007, affine_share=0.544, remainder=0.393
- order_affine_then_mu: affine_share=0.658, mu_share=-0.121, remainder=0.393

## 문항 집합: common_correct (문항 19, 영어 단어 19)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | 0.401 | [-0.091, 0.777] | - | - | 0.435 |
| mean_task | 0.430 | [-0.113, 0.831] | 0.030 | [-0.341, 0.470] | 0.515 |
| mean_wiki | 0.417 | [-0.033, 0.783] | 0.016 | [-0.148, 0.224] | 0.461 |
| affine | 0.112 | [-0.471, 0.598] | -0.289 | [-0.785, 0.185] | 0.126 |
| affine_nobias | 0.027 | [-0.512, 0.528] | -0.374 | [-0.861, 0.180] | 0.030 |
| tuned | 0.022 | [-0.575, 0.570] | -0.378 | [-0.811, -0.058] | 0.026 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: r_L 하락 (기각 방향)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 3.460, 평균 I_en(영어 입력) = 0.708, I_en > I 비율 = 0.105, Wilcoxon p = 0.00021. I > 0 비율 = 0.947
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 13 | 3.381 | 0.267 | 0.230 | 0.326 | -0.001 | -0.001 | -0.024 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.886 | Y |
| s_logit | 0.958 | Y |
| s_mean_task | 0.788 | Y |
| s_mean_wiki | 0.921 | Y |
| s_affine | 0.892 | Y |
| s_affine_nobias | 0.891 | Y |
| s_tuned | 0.827 | Y |

템플릿별 lens 순위: T1: logit > mean_wiki > mean_task > affine > affine_nobias > tuned; T2: mean_task > logit > mean_wiki > affine > affine_nobias > tuned; T3: logit > mean_wiki > mean_task > affine > affine_nobias > tuned; T4: mean_wiki > logit > mean_task > affine > tuned > affine_nobias

불일치 (logit lens 높음·간섭 낮음): B045(household), B055(capacity), B015(apology), B053(distance), B069(cremation), B063(doubt), B105(guidance), B001(pear)

불일치 (logit lens 낮음·간섭 높음): B059(thinking), B117(denial), B093(audit), B119(surface), B083(region), B014(bottle), B047(glue), B005(chestnut)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.305 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = 0.332 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.438, affine_nobias=0.354, logit=0.943, mean_task=0.955, mean_wiki=0.949, tuned=0.391

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.438 | 0.159 | 0.478 | 8.808 | 6.837 |
| affine_nobias | 0.354 | 0.179 | 0.528 | 7.662 | 6.720 |
| logit | 0.943 | 0.944 | 0.881 | 9.137 | 9.321 |
| mean_task | 0.955 | 0.957 | 0.914 | 11.329 | 10.709 |
| mean_wiki | 0.949 | 0.950 | 0.877 | 9.444 | 9.674 |
| tuned | 0.391 | 0.377 | 0.918 | 6.861 | 6.961 |

- order_mu_then_affine[mean_task]: mu_share=-0.012, affine_share=0.517, remainder=0.438
- order_mu_then_affine[mean_wiki]: mu_share=-0.006, affine_share=0.511, remainder=0.438
- order_affine_then_mu: affine_share=0.589, mu_share=-0.084, remainder=0.438

**repeat** E: affine=0.393, affine_nobias=0.272, logit=0.930, mean_task=0.928, mean_wiki=0.937, tuned=0.416

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.393 | 0.039 | 0.550 | 8.027 | 5.852 |
| affine_nobias | 0.272 | 0.071 | 0.633 | 6.667 | 5.551 |
| logit | 0.930 | 0.930 | 0.858 | 10.390 | 10.890 |
| mean_task | 0.928 | 0.929 | 0.871 | 10.674 | 11.295 |
| mean_wiki | 0.937 | 0.937 | 0.853 | 10.409 | 10.804 |
| tuned | 0.416 | 0.406 | 0.900 | 5.599 | 6.046 |

- order_mu_then_affine[mean_task]: mu_share=0.001, affine_share=0.536, remainder=0.393
- order_mu_then_affine[mean_wiki]: mu_share=-0.007, affine_share=0.544, remainder=0.393
- order_affine_then_mu: affine_share=0.658, mu_share=-0.121, remainder=0.393
