# LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct

중간 층 ℳ = 8–22 (전체 30층의 25–75%)

## sanity check

```
{
 "final_layer_top1_match": 0.9901960784313726,
 "final_layer_max_abs_dlogp": 0.042893826961517334,
 "mu0_equals_logit_maxdiff": 0.0,
 "ok": true
}
```

affine 검증 R² (중간 층): ℓ=8: R²=0.459 (λ=0.1), ℓ=9: R²=0.476 (λ=0.1), ℓ=10: R²=0.488 (λ=0.1), ℓ=11: R²=0.490 (λ=0.1), ℓ=12: R²=0.493 (λ=0.1), ℓ=13: R²=0.501 (λ=0.1), ℓ=14: R²=0.509 (λ=0.1), ℓ=15: R²=0.516 (λ=0.1), ℓ=16: R²=0.525 (λ=0.1), ℓ=17: R²=0.533 (λ=0.1), ℓ=18: R²=0.538 (λ=0.1), ℓ=19: R²=0.552 (λ=0.1), ℓ=20: R²=0.563 (λ=0.1), ℓ=21: R²=0.576 (λ=0.1), ℓ=22: R²=0.590 (λ=0.1)

tuned 검증 KL (위키, logit lens → tuned, 중간 층): ℓ=8: 8.52→2.37, ℓ=9: 8.47→2.30, ℓ=10: 8.47→2.25, ℓ=11: 8.54→2.20, ℓ=12: 8.47→2.19, ℓ=13: 8.52→2.15, ℓ=14: 8.48→2.06, ℓ=15: 8.24→2.02, ℓ=16: 8.20→1.96, ℓ=17: 8.17→1.93, ℓ=18: 7.96→1.89, ℓ=19: 7.59→1.80, ℓ=20: 7.34→1.71, ℓ=21: 7.01→1.63, ℓ=22: 6.58→1.53

### 중간 층 판독 1위 토큰 (번역, 입력 조건, 자주 나온 순)

- affine: '\n'×3548, '大'×26, '�'×14, '�'×10, '人'×2
- affine_nobias: '\n'×3450, '�'×76, '大'×48, '�'×24, '人'×2
- logit: ' chuckled'×871, ' respectfully'×339, ' —.'×188, 'onas'×157, 'icho'×131, 'år'×130, ' sweet'×120, 'ucc'×116, ' debatable'×114, ' Philippe'×112, ' standout'×100, ' Medicine'×98
- mean_task: ' gamb'×120, ' 겠다는'×102, ' trailing'×102, ' Jain'×100, 'yth'×89, ' Macron'×62, 'grav'×61, '욕장'×60, 'ho'×60, ' Lay'×60, '�'×60, ' 완'×60
- mean_wiki: ' chuckled'×464, 'icho'×362, ' infiltr'×320, '듬해'×278, 'ivas'×250, ' outnumber'×240, ' Matth'×240, ' %/'×238, ' respectfully'×236, '[|endofturn|]'×130, ' prolifer'×124, 'lon'×108
- tuned: '\n'×763, '[|endofturn|]'×560, ' chuckled'×557, '  '×437, '('×243, 'N'×238, '현'×180, '�'×114, '접'×106, '�'×100, '지상'×76, ' 주인공'×64

## 문항 집합: own_correct (문항 20, 영어 단어 20)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | -0.307 | [-0.730, 0.203] | - | - | -0.339 |
| mean_task | 0.198 | [-0.332, 0.690] | 0.505 | [-0.087, 1.079] | 0.309 |
| mean_wiki | -0.148 | [-0.630, 0.399] | 0.159 | [-0.037, 0.437] | -0.163 |
| affine | -0.244 | [-0.722, 0.375] | 0.063 | [-0.584, 0.728] | -0.265 |
| affine_nobias | -0.283 | [-0.752, 0.357] | 0.024 | [-0.600, 0.647] | -0.309 |
| tuned | -0.432 | [-0.832, 0.193] | -0.125 | [-0.590, 0.364] | -0.466 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 3.574, 평균 I_en(영어 입력) = 0.683, I_en > I 비율 = 0.050, Wilcoxon p = 5.7e-06. I > 0 비율 = 0.900
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 14 | 3.887 | -0.202 | 0.216 | 0.091 | -0.263 | -0.249 | -0.473 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.866 | Y |
| s_logit | 0.951 | Y |
| s_mean_task | 0.475 | N |
| s_mean_wiki | 0.956 | Y |
| s_affine | 0.979 | Y |
| s_affine_nobias | 0.971 | Y |
| s_tuned | 0.995 | Y |

템플릿별 lens 순위: T1: mean_task > mean_wiki > logit > affine > affine_nobias > tuned; T2: mean_task > mean_wiki > tuned > affine_nobias > logit > affine; T3: mean_task > mean_wiki > affine_nobias > logit > affine > tuned; T4: mean_task > mean_wiki > logit > affine > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): B051(wish), B015(apology), B047(glue), B063(doubt), B045(household), B055(capacity), B083(region), B039(intention)

불일치 (logit lens 낮음·간섭 높음): B041(biography), B105(guidance), B069(cremation), B053(distance), B001(pear), B014(bottle), B059(thinking), B097(messenger)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.372 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.125 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.200, affine_nobias=0.118, logit=0.667, mean_task=0.703, mean_wiki=0.673, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.200 | 0.104 | 0.062 | 15.736 | 16.533 |
| affine_nobias | 0.118 | 0.087 | 0.137 | 13.161 | 13.621 |
| logit | 0.667 | 0.667 | 0.944 | 10.787 | 11.066 |
| mean_task | 0.703 | 0.703 | 0.951 | 10.865 | 10.963 |
| mean_wiki | 0.673 | 0.673 | 0.944 | 10.994 | 11.121 |
| tuned | 0.553 | 0.552 | 0.905 | 9.028 | 9.175 |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.503, remainder=0.200
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.472, remainder=0.200
- order_affine_then_mu: affine_share=0.549, mu_share=-0.082, remainder=0.200

**repeat** E: affine=0.203, affine_nobias=0.118, logit=0.671, mean_task=0.729, mean_wiki=0.678, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.203 | 0.092 | 0.002 | 17.027 | 16.872 |
| affine_nobias | 0.118 | 0.033 | 0.047 | 13.591 | 13.593 |
| logit | 0.671 | 0.671 | 0.946 | 12.890 | 12.932 |
| mean_task | 0.729 | 0.729 | 0.962 | 14.278 | 14.217 |
| mean_wiki | 0.678 | 0.678 | 0.947 | 12.397 | 12.449 |
| tuned | 0.553 | 0.552 | 0.931 | 11.392 | 11.410 |

- order_mu_then_affine[mean_task]: mu_share=-0.059, affine_share=0.527, remainder=0.203
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.476, remainder=0.203
- order_affine_then_mu: affine_share=0.552, mu_share=-0.085, remainder=0.203

## 문항 집합: common_correct (문항 19, 영어 단어 19)

### 예측 2: lens 점수 s_L과 간섭 I의 부분 Spearman (공변량: zipf_en, zipf_ko_input, zipf_zh_distractor)

| lens | r_L | 95% CI | logit 대비 Δ | Δ 95% CI | 신뢰도 보정 r |
|---|---|---|---|---|---|
| logit | -0.328 | [-0.763, 0.244] | - | - | -0.362 |
| mean_task | 0.168 | [-0.406, 0.688] | 0.497 | [-0.144, 1.097] | 0.269 |
| mean_wiki | -0.175 | [-0.659, 0.416] | 0.153 | [-0.064, 0.429] | -0.193 |
| affine | -0.244 | [-0.738, 0.375] | 0.085 | [-0.576, 0.745] | -0.266 |
| affine_nobias | -0.299 | [-0.770, 0.337] | 0.029 | [-0.595, 0.672] | -0.329 |
| tuned | -0.420 | [-0.857, 0.244] | -0.092 | [-0.598, 0.437] | -0.455 |

판정 참고(6절): Δ = r(보정 lens) − r(logit). Δ CI 상한 < 0 → 'r_L 하락'(기각 방향). Δ CI 하한 > −0.1 → 'r_L 유지'(지지 방향). 그 사이는 판단 불가. F1·F2를 통과했을 때만 해석.

- mean_task: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- mean_wiki: r_L 유지 (지지 방향, Δ CI 하한 > −0.1)
- affine: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- affine_nobias: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)
- tuned: 판단 불가 (Δ CI가 0과 −0.1를 모두 포함, 표본 부족)

### F1 간섭 점수 타당성

- 양성 대조: 평균 I(한국어 입력) = 3.520, 평균 I_en(영어 입력) = 0.604, I_en > I 비율 = 0.053, Wilcoxon p = 1.1e-05. I > 0 비율 = 0.895
- 음성 대조(한국어 다의어 '배' 등)는 데이터셋 A에 없음 → D3 필요

어원별 (문항 8개 이상인 집단):

| 어원 | n | 평균 I | logit | mean_task | mean_wiki | affine | affine_nobias | tuned |
|---|---|---|---|---|---|---|---|---|
| 한자어쌍 | 13 | 3.833 | -0.225 | 0.213 | 0.042 | -0.280 | -0.280 | -0.438 |

### F2 신뢰도 (split-half, Spearman–Brown)

| 변수 | 신뢰도 | 0.7 이상 |
|---|---|---|
| I | 0.858 | Y |
| s_logit | 0.959 | Y |
| s_mean_task | 0.458 | N |
| s_mean_wiki | 0.960 | Y |
| s_affine | 0.976 | Y |
| s_affine_nobias | 0.966 | Y |
| s_tuned | 0.994 | Y |

템플릿별 lens 순위: T1: mean_task > mean_wiki > logit > affine > affine_nobias > tuned; T2: mean_task > mean_wiki > tuned > affine_nobias > affine > logit; T3: mean_task > mean_wiki > affine_nobias > affine > logit > tuned; T4: mean_task > mean_wiki > logit > affine > affine_nobias > tuned

불일치 (logit lens 높음·간섭 낮음): B051(wish), B015(apology), B047(glue), B063(doubt), B045(household), B055(capacity), B083(region), B039(intention)

불일치 (logit lens 낮음·간섭 높음): B041(biography), B105(guidance), B069(cremation), B053(distance), B001(pear), B014(bottle), B059(thinking), B117(denial)

- mu_share_vs_zipf_en_mean_task: Spearman = 0.338 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)
- mu_share_vs_zipf_en_mean_wiki: Spearman = -0.151 (높으면 μ 몫이 빈도와 겹쳐 μ 판정이 약해짐)

### 예측 1: 중간 층 영어 비중 E 분해 (ℳ 평균, 입력 조건)

**translate** E: affine=0.200, affine_nobias=0.118, logit=0.667, mean_task=0.704, mean_wiki=0.673, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.200 | 0.105 | 0.062 | 15.909 | 16.744 |
| affine_nobias | 0.118 | 0.087 | 0.137 | 13.330 | 13.787 |
| logit | 0.667 | 0.667 | 0.944 | 10.943 | 11.172 |
| mean_task | 0.704 | 0.703 | 0.950 | 11.011 | 11.102 |
| mean_wiki | 0.673 | 0.673 | 0.944 | 11.154 | 11.240 |
| tuned | 0.553 | 0.552 | 0.905 | 9.195 | 9.308 |

- order_mu_then_affine[mean_task]: mu_share=-0.036, affine_share=0.504, remainder=0.200
- order_mu_then_affine[mean_wiki]: mu_share=-0.005, affine_share=0.473, remainder=0.200
- order_affine_then_mu: affine_share=0.550, mu_share=-0.082, remainder=0.200

**repeat** E: affine=0.202, affine_nobias=0.117, logit=0.671, mean_task=0.729, mean_wiki=0.679, tuned=0.553

| lens | E | E_w (질량 가중) | 언어 질량 | KL(최종‖lens) 평균 | KL 중앙값 |
|---|---|---|---|---|---|
| affine | 0.202 | 0.092 | 0.002 | 17.033 | 16.874 |
| affine_nobias | 0.117 | 0.033 | 0.047 | 13.597 | 13.622 |
| logit | 0.671 | 0.671 | 0.946 | 12.872 | 12.893 |
| mean_task | 0.729 | 0.729 | 0.962 | 14.243 | 14.180 |
| mean_wiki | 0.679 | 0.679 | 0.947 | 12.388 | 12.442 |
| tuned | 0.553 | 0.552 | 0.931 | 11.374 | 11.396 |

- order_mu_then_affine[mean_task]: mu_share=-0.059, affine_share=0.527, remainder=0.202
- order_mu_then_affine[mean_wiki]: mu_share=-0.008, affine_share=0.477, remainder=0.202
- order_affine_then_mu: affine_share=0.553, mu_share=-0.084, remainder=0.202
